import { Events, Collection } from "discord.js";
import client, { type BotCommand } from "./client.js";
import { handleReady } from "./events/ready.js";
import { handleInteractionCreate } from "./events/interactionCreate.js";
import { deployCommands } from "./deploy.js";
import { logger } from "../lib/logger.js";
import * as commands from "./commands/index.js";

export async function startBot() {
  const token = process.env["DISCORD_TOKEN"];
  const clientId = process.env["DISCORD_CLIENT_ID"];

  if (!token) {
    logger.warn("DISCORD_TOKEN not set — Discord bot will not start");
    return;
  }

  if (!clientId) {
    logger.warn("DISCORD_CLIENT_ID not set — Discord bot will not start");
    return;
  }

  // Register commands on the client
  const commandsCollection = new Collection<string, BotCommand>();
  for (const [, cmd] of Object.entries(commands)) {
    commandsCollection.set(cmd.data.name, cmd as BotCommand);
  }
  (client as unknown as { commands: Collection<string, BotCommand> }).commands = commandsCollection;

  // Event: Ready
  client.once(Events.ClientReady, (c) => {
    void handleReady(c);

    // Deploy commands to all guilds on startup for instant availability
    for (const [, guild] of c.guilds.cache) {
      deployCommands(clientId, guild.id).catch((err) =>
        logger.error({ err, guildId: guild.id }, "Failed to deploy commands"),
      );
    }

    // Also deploy global commands (takes ~1hr to propagate but ensures new guilds get them)
    deployCommands(clientId).catch((err) =>
      logger.error({ err }, "Failed to deploy global commands"),
    );
  });

  // Event: New guild join — deploy commands
  client.on(Events.GuildCreate, (guild) => {
    deployCommands(clientId, guild.id).catch((err) =>
      logger.error({ err, guildId: guild.id }, "Failed to deploy commands on guild join"),
    );
  });

  // Event: Interaction
  client.on(Events.InteractionCreate, (interaction) => {
    void handleInteractionCreate(interaction, client);
  });

  // Event: Error
  client.on(Events.Error, (err) => {
    logger.error({ err }, "Discord client error");
  });

  client.on(Events.Warn, (msg) => {
    logger.warn({ msg }, "Discord client warning");
  });

  try {
    await client.login(token);
    logger.info("Discord bot login initiated");
  } catch (err) {
    logger.error({ err }, "Failed to login to Discord");
    throw err;
  }
}
