import { SlashCommandBuilder, type ChatInputCommandInteraction } from "discord.js";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { buildProfileEmbed } from "../embeds/profile.js";

export const data = new SlashCommandBuilder()
  .setName("profile")
  .setDescription("View your or another player's TestYourTier profile")
  .addUserOption((o) =>
    o.setName("user").setDescription("User to view (leave blank for your own)").setRequired(false),
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply();

  const target = interaction.options.getUser("user") ?? interaction.user;

  const user = await db.query.usersTable.findFirst({
    where: eq(usersTable.discordId, target.id),
  });

  if (!user) {
    await interaction.editReply({
      content:
        target.id === interaction.user.id
          ? "❌ You don't have a profile yet! Click **Register / Update Profile** in the registration channel to get started."
          : `❌ **${target.username}** doesn't have a TestYourTier profile yet.`,
    });
    return;
  }

  const embed = buildProfileEmbed(user, target.tag);
  await interaction.editReply({ embeds: [embed] });
}
