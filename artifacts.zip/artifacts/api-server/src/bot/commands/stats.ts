import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { db } from "@workspace/db";
import {
  usersTable,
  matchResultsTable,
  queueSessionsTable,
  ticketsTable,
} from "@workspace/db";
import { eq, count, sum, desc } from "drizzle-orm";
import { COLORS } from "../embeds/colors.js";
import { GAMEMODES, GAMEMODE_EMOJIS, type Gamemode } from "../utils/gamemodes.js";
import { TIERS, getTierColor } from "../utils/tiers.js";

export const data = new SlashCommandBuilder()
  .setName("stats")
  .setDescription("View server or gamemode statistics")
  .addSubcommand((sub) =>
    sub.setName("server").setDescription("Show overall server statistics"),
  )
  .addSubcommand((sub) =>
    sub
      .setName("gamemode")
      .setDescription("Show statistics for a specific gamemode")
      .addStringOption((o) =>
        o.setName("gamemode").setDescription("Gamemode to view stats for").setRequired(true)
          .addChoices(...GAMEMODES.map((g) => ({ name: g, value: g }))),
      ),
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply({ ephemeral: false });

  const sub = interaction.options.getSubcommand(true);

  // ── /stats server ──────────────────────────────────────────────────────────
  if (sub === "server") {
    const [totalPlayersRow] = await db.select({ n: count() }).from(usersTable);
    const [totalTestsRow]   = await db.select({ n: sum(usersTable.totalTests) }).from(usersTable);
    const [totalResultsRow] = await db.select({ n: count() }).from(matchResultsTable);
    const [openQueuesRow]   = await db.select({ n: count() }).from(queueSessionsTable).where(eq(queueSessionsTable.status, "open"));
    const [openTicketsRow]  = await db.select({ n: count() }).from(ticketsTable).where(eq(ticketsTable.status, "open"));

    const totalPlayers = totalPlayersRow?.n ?? 0;
    const totalTests   = Number(totalTestsRow?.n ?? 0);
    const totalResults = totalResultsRow?.n ?? 0;
    const openQueues   = openQueuesRow?.n ?? 0;
    const openTickets  = openTicketsRow?.n ?? 0;

    // Tier distribution
    const tierDist = await db
      .select({ tier: usersTable.currentTier, n: count() })
      .from(usersTable)
      .groupBy(usersTable.currentTier)
      .orderBy(desc(count()));

    // Most tested gamemodes
    const gamemodeStats = await db
      .select({ gamemode: matchResultsTable.gamemode, n: count() })
      .from(matchResultsTable)
      .groupBy(matchResultsTable.gamemode)
      .orderBy(desc(count()))
      .limit(8);

    // Format tier distribution
    const tierGroups = ["HT", "MT", "LT", "Unranked"];
    const tierLines = tierGroups.map((group) => {
      if (group === "Unranked") {
        const row = tierDist.find((r) => r.tier === "Unranked");
        return `⚪ **Unranked** — ${row?.n ?? 0}`;
      }
      const tiers = TIERS.filter((t) => t.startsWith(group));
      const total = tiers.reduce((acc, t) => {
        const row = tierDist.find((r) => r.tier === t);
        return acc + (row?.n ?? 0);
      }, 0);
      const icon = group === "HT" ? "🔴" : group === "MT" ? "🟠" : "🟢";
      return `${icon} **${group === "HT" ? "High Tier" : group === "MT" ? "Mid Tier" : "Low Tier"}** — ${total} players`;
    });

    const gamemodeLines = gamemodeStats.length > 0
      ? gamemodeStats.map((row) => {
          const emoji = GAMEMODE_EMOJIS[row.gamemode as Gamemode] ?? "🎮";
          return `${emoji} ${row.gamemode} — **${row.n}** tests`;
        }).join("\n")
      : "No test data yet.";

    const embed = new EmbedBuilder()
      .setColor(COLORS.TYT)
      .setTitle("📊 Server Statistics")
      .addFields(
        {
          name: "📈 Overview",
          value:
            `👥 **Players Registered:** ${totalPlayers}\n` +
            `📝 **Total Tests Done:** ${totalTests}\n` +
            `📋 **Match Results Recorded:** ${totalResults}\n` +
            `⚔️ **Queues Open Right Now:** ${openQueues}\n` +
            `🎫 **Open Tickets:** ${openTickets}`,
          inline: false,
        },
        {
          name: "🏆 Tier Distribution",
          value: tierLines.join("\n") || "No players registered yet.",
          inline: true,
        },
        {
          name: "🎮 Tests by Gamemode",
          value: gamemodeLines,
          inline: true,
        },
      )
      .setTimestamp()
      .setFooter({ text: "TestYourTier" });

    await interaction.editReply({ embeds: [embed] });
    return;
  }

  // ── /stats gamemode ────────────────────────────────────────────────────────
  if (sub === "gamemode") {
    const gamemode = interaction.options.getString("gamemode", true) as Gamemode;
    const emoji = GAMEMODE_EMOJIS[gamemode] ?? "⚔️";

    const [totalResultsRow] = await db
      .select({ n: count() })
      .from(matchResultsTable)
      .where(eq(matchResultsTable.gamemode, gamemode));

    const openSession = await db.query.queueSessionsTable.findFirst({
      where: eq(queueSessionsTable.status, "open") &&
        eq(queueSessionsTable.gamemode, gamemode) as never,
    });

    // Tier distribution for this gamemode
    const tierDist = await db
      .select({ tier: matchResultsTable.newTier, n: count() })
      .from(matchResultsTable)
      .where(eq(matchResultsTable.gamemode, gamemode))
      .groupBy(matchResultsTable.newTier)
      .orderBy(desc(count()))
      .limit(5);

    // Top players in this gamemode (by points, who have played it)
    const topPlayerIds = await db
      .select({ playerId: matchResultsTable.playerId })
      .from(matchResultsTable)
      .where(eq(matchResultsTable.gamemode, gamemode))
      .groupBy(matchResultsTable.playerId)
      .limit(50);

    const playerIdSet = new Set(topPlayerIds.map((r) => r.playerId));

    const topPlayers = await db.query.usersTable.findMany({
      orderBy: [desc(usersTable.points)],
      limit: 100,
    });

    const gamemodeTopPlayers = topPlayers
      .filter((p) => playerIdSet.has(p.discordId))
      .slice(0, 3);

    const topLines = gamemodeTopPlayers.length > 0
      ? gamemodeTopPlayers.map((p, i) =>
          `${["🥇", "🥈", "🥉"][i]} **${p.ign}** — ${p.currentTier} (${p.points}pts)`,
        ).join("\n")
      : "No ranked players yet.";

    const tierLines = tierDist.length > 0
      ? tierDist.map((r) => `• **${r.tier}** — ${r.n} result${r.n !== 1 ? "s" : ""}`).join("\n")
      : "No results yet.";

    const queueStatus = openSession
      ? `✅ Queue is **OPEN** — Tester: <@${openSession.testerId}>`
      : "🔴 No queue open right now";

    const embed = new EmbedBuilder()
      .setColor(COLORS.QUEUE)
      .setTitle(`${emoji} ${gamemode} — Gamemode Stats`)
      .addFields(
        {
          name: "📈 Activity",
          value:
            `📝 **Total Tests:** ${totalResultsRow?.n ?? 0}\n` +
            `⚔️ **Queue:** ${queueStatus}`,
          inline: false,
        },
        { name: "🏆 Top Players",      value: topLines,  inline: true },
        { name: "📊 Common Results",   value: tierLines, inline: true },
      )
      .setTimestamp()
      .setFooter({ text: "TestYourTier" });

    await interaction.editReply({ embeds: [embed] });
    return;
  }

  await interaction.editReply({ content: "❌ Unknown subcommand." });
}
