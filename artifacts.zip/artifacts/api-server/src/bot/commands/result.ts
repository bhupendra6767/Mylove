import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  ChannelType,
  TextChannel,
} from "discord.js";
import { db } from "@workspace/db";
import { usersTable, matchResultsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { buildResultEmbed } from "../embeds/result.js";
import { isTester } from "../utils/permissions.js";
import { GAMEMODES, type Gamemode } from "../utils/gamemodes.js";
import { TIERS, type Tier, TIER_POINTS } from "../utils/tiers.js";
import { logAction } from "../utils/logger.js";

export const data = new SlashCommandBuilder()
  .setName("result")
  .setDescription("Submit a tier test result")
  .addSubcommand((sub) =>
    sub
      .setName("submit")
      .setDescription("Submit a tier test result for a player")
      .addUserOption((o) => o.setName("player").setDescription("The player who was tested").setRequired(true))
      .addStringOption((o) =>
        o.setName("gamemode").setDescription("Gamemode tested").setRequired(true)
          .addChoices(...GAMEMODES.map((g) => ({ name: g, value: g }))),
      )
      .addStringOption((o) => o.setName("score").setDescription("Match score (e.g. Won 3-1)").setRequired(true))
      .addStringOption((o) =>
        o.setName("tier").setDescription("The tier the player earned").setRequired(true)
          .addChoices(...TIERS.filter((t) => t !== "Unranked").map((t) => ({ name: t, value: t }))),
      )
      .addStringOption((o) => o.setName("notes").setDescription("Optional notes about the test").setRequired(false)),
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    await interaction.reply({ content: "❌ This command must be used in a server.", ephemeral: true });
    return;
  }

  const sub = interaction.options.getSubcommand();
  if (sub !== "submit") return;

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!isTester(member)) {
    await interaction.reply({ content: "❌ You need **TYT Tester** or higher to submit results.", ephemeral: true });
    return;
  }

  await interaction.deferReply();

  const targetUser = interaction.options.getUser("player", true);
  const gamemode = interaction.options.getString("gamemode", true) as Gamemode;
  const score = interaction.options.getString("score", true);
  const newTier = interaction.options.getString("tier", true) as Tier;
  const notes = interaction.options.getString("notes") ?? undefined;

  // Fetch or create user record
  let playerRecord = await db.query.usersTable.findFirst({
    where: eq(usersTable.discordId, targetUser.id),
  });

  const previousTier = playerRecord?.currentTier ?? "Unranked";

  // Determine win/loss from score (simple: if "Won" in score → win, else loss)
  const isWin = /won|win|pass/i.test(score);

  // Update or create user record
  if (playerRecord) {
    await db
      .update(usersTable)
      .set({
        currentTier: newTier,
        currentGamemode: gamemode,
        wins: isWin ? playerRecord.wins + 1 : playerRecord.wins,
        losses: isWin ? playerRecord.losses : playerRecord.losses + 1,
        winStreak: isWin ? playerRecord.winStreak + 1 : 0,
        totalTests: playerRecord.totalTests + 1,
        points: TIER_POINTS[newTier] ?? 0,
        updatedAt: new Date(),
      })
      .where(eq(usersTable.discordId, targetUser.id));
    playerRecord = { ...playerRecord, currentTier: newTier };
  }

  // Save match result
  await db.insert(matchResultsTable).values({
    testerId: interaction.user.id,
    playerId: targetUser.id,
    gamemode,
    score,
    previousTier,
    newTier,
    outcome: isWin ? "passed" : "failed",
    notes,
  });

  // Remove old tier roles and assign new one
  const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
  if (targetMember) {
    const tierRoleNames = TIERS.filter((t) => t !== "Unranked");
    for (const tierName of tierRoleNames) {
      const role = interaction.guild.roles.cache.find((r) => r.name === tierName);
      if (role && targetMember.roles.cache.has(role.id)) {
        await targetMember.roles.remove(role).catch(() => null);
      }
    }
    // Remove Unranked if present
    const unrankedRole = interaction.guild.roles.cache.find((r) => r.name === "Unranked");
    if (unrankedRole) await targetMember.roles.remove(unrankedRole).catch(() => null);

    // Add new tier role
    const newRole = interaction.guild.roles.cache.find((r) => r.name === newTier);
    if (newRole) await targetMember.roles.add(newRole).catch(() => null);
  }

  const updatedRecord = await db.query.usersTable.findFirst({
    where: eq(usersTable.discordId, targetUser.id),
  });

  const embed = buildResultEmbed({
    playerTag: targetUser.id,
    playerIgn: updatedRecord?.ign ?? targetUser.username,
    testerTag: interaction.user.id,
    gamemode,
    score,
    previousTier,
    newTier,
    notes,
    skinUrl: updatedRecord?.skinUrl ?? undefined,
    accountType: updatedRecord?.accountType ?? "premium",
  });

  // Post to results channel
  const resultsChannel = interaction.guild.channels.cache.find(
    (c) => (c.name === "results" || c.name.includes("results")) && c.type === ChannelType.GuildText,
  ) as TextChannel | undefined;

  if (resultsChannel && resultsChannel.id !== interaction.channelId) {
    await resultsChannel.send({ content: `<@${targetUser.id}>`, embeds: [embed] });
  }

  // Post to high-results if HT tier
  if (newTier.startsWith("HT")) {
    const highResultsChannel = interaction.guild.channels.cache.find(
      (c) => (c.name === "high-results" || c.name.includes("high-result")) && c.type === ChannelType.GuildText,
    ) as TextChannel | undefined;
    if (highResultsChannel) {
      await highResultsChannel.send({ content: `<@${targetUser.id}>`, embeds: [embed] }).catch(() => null);
    }
  }

  await logAction(
    interaction.guild,
    "Tier Result Submitted",
    targetUser.id,
    `${previousTier} → ${newTier} | ${gamemode} | Tester: ${interaction.user.tag}`,
  );

  await interaction.editReply({ embeds: [embed] });
}
