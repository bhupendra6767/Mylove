import { SlashCommandBuilder, type ChatInputCommandInteraction, type TextChannel } from "discord.js";
import { buildSupportPortalEmbed, buildSupportButtons } from "../embeds/ticket.js";
import { isStaff } from "../utils/permissions.js";

export const data = new SlashCommandBuilder()
  .setName("setup-support")
  .setDescription("Post the TestYourTier support ticket panel in this channel");

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    await interaction.reply({ content: "❌ This command must be used in a server.", ephemeral: true });
    return;
  }

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!isStaff(member)) {
    await interaction.reply({ content: "❌ You need **TYT Staff** or higher to use this command.", ephemeral: true });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const embed = buildSupportPortalEmbed();
  const buttons = buildSupportButtons();

  await (interaction.channel as TextChannel).send({ embeds: [embed], components: buttons });
  await interaction.editReply({ content: "✅ Support panel posted successfully." });
}
