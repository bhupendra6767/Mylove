import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import { COLORS } from "../embeds/colors.js";

export const data = new SlashCommandBuilder()
  .setName("help")
  .setDescription("View all TestYourTier bot commands and how to use them");

const PAGES = [
  {
    label: "⚙️ Setup",
    embed: () =>
      new EmbedBuilder()
        .setColor(COLORS.PRIMARY)
        .setTitle("⚙️ TestYourTier — Setup Commands")
        .setDescription("Admin and staff commands for server configuration. Run `/autosetup` first.")
        .addFields(
          {
            name: "⚙️ `/autosetup`",
            value:
              "**Permission:** Administrator\n" +
              "Creates every category, channel, and role the bot needs, then walks you through posting the registration panel, support portal step by step.\n" +
              "➜ *Always run this first in a new server.*",
            inline: false,
          },
          {
            name: "📋 `/setup-registration`",
            value:
              "**Permission:** TYT Staff+\n" +
              "Posts the player registration panel (Register button + gamemode waitlist) in the current channel.\n" +
              "➜ *Use to re-post the panel manually.*",
            inline: false,
          },
          {
            name: "🎫 `/setup-support`",
            value:
              "**Permission:** TYT Staff+\n" +
              "Posts the 6-category support ticket portal in the current channel.\n" +
              "Categories: General Help, Player Report, Punishment Appeal, Tier Dispute, Tester Feedback, Other.",
            inline: false,
          },
          {
            name: "⚔️ `/setup-queue [gamemode]`",
            value:
              "**Permission:** TYT Tester+\n" +
              "Opens a live testing queue for a gamemode in the current channel. Pings the gamemode's waitlist role.\n" +
              "**Gamemodes:** Axe & Shield, Neth Pot, Dia Pot, SMP Kit, Mace, Sword, UHC, CPvP",
            inline: false,
          },
        )
        .setFooter({ text: "Page 1 / 4 — Setup Commands" }),
  },
  {
    label: "🏆 Testing",
    embed: () =>
      new EmbedBuilder()
        .setColor(COLORS.RESULT)
        .setTitle("🏆 TestYourTier — Testing Commands")
        .setDescription("Commands for recording results and tracking queue activity.")
        .addFields(
          {
            name: "📝 `/result submit`",
            value:
              "**Permission:** TYT Tester+\n" +
              "Submit a tier test result for a player. Updates their tier role automatically.\n\n" +
              "**Options:** `player` · `gamemode` · `score` (e.g. `Won 3-1`) · `tier` (HT1–LT5) · `notes` *(optional)*\n" +
              "➜ *Posts to #results and #high-results for HT tiers. Updates role.*",
            inline: false,
          },
          {
            name: "📜 `/history [player]`",
            value:
              "**Permission:** Everyone\n" +
              "View the last 10 tier test results for yourself or another player.\n" +
              "Shows: gamemode, score, tier progression, tester, timestamp.\n" +
              "➜ *Leave `player` blank to view your own history.*",
            inline: false,
          },
          {
            name: "⚔️ `/queues`",
            value:
              "**Permission:** Everyone\n" +
              "Shows the live status of all 8 gamemode queues — which are open, how many players are in each, and which tester is running it.\n" +
              "➜ *Use this to see if a queue is open before trying to join.*",
            inline: false,
          },
          {
            name: "🕹️ Queue Flow",
            value:
              "1. Tester runs `/setup-queue [gamemode]` → queue opens, waitlist pinged\n" +
              "2. Players click **Join** to enter queue\n" +
              "3. Tester clicks **Next** → private thread created with next player\n" +
              "4. Tester clicks **Close** → enters notes → queue closes\n" +
              "5. Tester runs `/result submit` → result posted, role updated",
            inline: false,
          },
        )
        .setFooter({ text: "Page 2 / 4 — Testing Commands" }),
  },
  {
    label: "📊 Stats",
    embed: () =>
      new EmbedBuilder()
        .setColor(COLORS.SUCCESS)
        .setTitle("📊 TestYourTier — Stats & Info Commands")
        .setDescription("Commands for viewing player stats, server analytics, and tier information.")
        .addFields(
          {
            name: "👤 `/profile [player]`",
            value:
              "**Permission:** Everyone\n" +
              "Full player profile card: IGN, tier, wins, losses, win rate, win streak, points.\n" +
              "➜ *Leave blank for your own. Player must be registered.*",
            inline: false,
          },
          {
            name: "🏅 `/leaderboard`",
            value:
              "**Permission:** Everyone\n" +
              "Paginated server leaderboard. Sort by: Points, Wins, Win Streak, Activity.\n" +
              "Use the gamemode dropdown to filter. ← Prev / Next → buttons to page.",
            inline: false,
          },
          {
            name: "📊 `/stats server` · `/stats gamemode [gm]`",
            value:
              "**Permission:** Everyone\n" +
              "`/stats server` — Total players, tests, tier distribution, most-tested gamemodes, open queues & tickets.\n" +
              "`/stats gamemode` — Tests, top players, and common tier results for a specific gamemode.",
            inline: false,
          },
          {
            name: "🏆 `/tier list` · `/tier info [tier]`",
            value:
              "**Permission:** Everyone\n" +
              "`/tier list` — Full tier table (HT1–LT5 + Unranked) with point values.\n" +
              "`/tier info [tier]` — Description, point value, and how to reach a specific tier.",
            inline: false,
          },
          {
            name: "🔍 `/search [ign]`",
            value:
              "**Permission:** Everyone\n" +
              "Search for registered players by IGN. Supports partial matches. Returns up to 10 results with tier and stats.",
            inline: false,
          },
        )
        .setFooter({ text: "Page 3 / 4 — Stats & Info Commands" }),
  },
  {
    label: "🔨 Staff",
    embed: () =>
      new EmbedBuilder()
        .setColor(COLORS.ERROR)
        .setTitle("🔨 TestYourTier — Staff Commands")
        .setDescription("Staff-only moderation and management tools.")
        .addFields(
          {
            name: "🏆 `/mod tier set [player] [tier]`",
            value:
              "**Permission:** TYT Staff+\n" +
              "Force-assign any tier to a player. Updates their tier role and point total automatically.\n" +
              "➜ *Use for correcting wrong test results or manual placements.*",
            inline: false,
          },
          {
            name: "⚪ `/mod tier remove [player]`",
            value:
              "**Permission:** TYT Staff+\n" +
              "Strip a player's tier and reset them to Unranked. Removes tier role.",
            inline: false,
          },
          {
            name: "🔨 `/mod queue ban [player] [reason]`",
            value:
              "**Permission:** TYT Staff+\n" +
              "Ban a player from joining any queue. They will see the ban reason when they try to join.",
            inline: false,
          },
          {
            name: "✅ `/mod queue unban [player]`",
            value:
              "**Permission:** TYT Staff+\n" +
              "Lift a queue ban and allow a player to join queues again.",
            inline: false,
          },
          {
            name: "🔍 `/mod player info [player]`",
            value:
              "**Permission:** TYT Staff+\n" +
              "Full staff-view of a player: all stats, ban status, registration date, and last 5 test results.",
            inline: false,
          },
          {
            name: "🗑️ `/mod player reset [player]`",
            value:
              "**Permission:** TYT Staff+\n" +
              "⚠️ **Irreversible.** Wipes ALL stats (wins, losses, points, streak, tests) and resets tier to Unranked.",
            inline: false,
          },
        )
        .setFooter({ text: "Page 4 / 4 — Staff Commands" }),
  },
];

function buildHelpComponents(page: number) {
  const prevDisabled = page === 0;
  const nextDisabled = page === PAGES.length - 1;

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`tyt_help_prev_${page}`)
      .setLabel("← Prev")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(prevDisabled),
    new ButtonBuilder()
      .setCustomId(`tyt_help_page_${page}`)
      .setLabel(`${PAGES[page]!.label} · ${page + 1}/${PAGES.length}`)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId(`tyt_help_next_${page}`)
      .setLabel("Next →")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(nextDisabled),
  );

  return [row];
}

export async function execute(interaction: ChatInputCommandInteraction) {
  const embed = PAGES[0]!.embed();
  const components = buildHelpComponents(0);
  await interaction.reply({ embeds: [embed], components, ephemeral: true });
}

export { buildHelpComponents, PAGES };
