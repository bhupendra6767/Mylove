import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { db } from "@workspace/db";
import { queueSessionsTable, queueEntriesTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";
import { COLORS } from "../embeds/colors.js";
import { GAMEMODES, GAMEMODE_EMOJIS, type Gamemode } from "../utils/gamemodes.js";

export const data = new SlashCommandBuilder()
  .setName("queues")
  .setDescription("See the current status of all testing queues");

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply({ ephemeral: false });

  const openSessions = await db.query.queueSessionsTable.findMany({
    where: eq(queueSessionsTable.status, "open"),
  });

  const embed = new EmbedBuilder()
    .setColor(COLORS.QUEUE)
    .setTitle("⚔️ Live Queue Status")
    .setTimestamp()
    .setFooter({ text: "TestYourTier" });

  if (openSessions.length === 0) {
    embed.setDescription("**No queues are currently open.**\n\nA tester can open a queue with `/setup-queue [gamemode]`.");
    await interaction.editReply({ embeds: [embed] });
    return;
  }

  // For each open session, get player count
  const sessionData = await Promise.all(
    openSessions.map(async (session) => {
      const [{ playerCount }] = await db
        .select({ playerCount: count() })
        .from(queueEntriesTable)
        .where(eq(queueEntriesTable.sessionId, session.id));
      return { session, playerCount: playerCount ?? 0 };
    }),
  );

  const fields = sessionData.map(({ session, playerCount }) => {
    const openedTs = Math.floor(new Date(session.openedAt).getTime() / 1000);
    const emoji = GAMEMODE_EMOJIS[session.gamemode as Gamemode] ?? "⚔️";
    return {
      name: `${emoji} ${session.gamemode}`,
      value:
        `👥 **${playerCount}** player${playerCount !== 1 ? "s" : ""} in queue\n` +
        `🧑‍💼 Tester: <@${session.testerId}>\n` +
        `⏱️ Opened <t:${openedTs}:R>\n` +
        `📍 <#${session.channelId}>`,
      inline: true,
    };
  });

  // Closed gamemodes
  const openGamemodes = new Set(openSessions.map((s) => s.gamemode));
  const closedGamemodes = GAMEMODES.filter((gm) => !openGamemodes.has(gm));

  if (closedGamemodes.length > 0) {
    fields.push({
      name: "🔴 No Queue Open",
      value: closedGamemodes
        .map((gm) => `${GAMEMODE_EMOJIS[gm]} ${gm}`)
        .join("\n"),
      inline: true,
    });
  }

  embed
    .setDescription(
      `**${openSessions.length}** of **${GAMEMODES.length}** queues active`,
    )
    .addFields(fields);

  await interaction.editReply({ embeds: [embed] });
}
