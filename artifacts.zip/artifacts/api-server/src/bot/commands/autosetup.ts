import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  ChannelType,
  PermissionFlagsBits,
  CategoryChannel,
  TextChannel,
} from "discord.js";
import { isAdmin } from "../utils/permissions.js";
import { TIERS } from "../utils/tiers.js";
import { GAMEMODES, GAMEMODE_CHANNEL_NAMES, GAMEMODE_WAITLIST_ROLES } from "../utils/gamemodes.js";
import { buildStep } from "../selectmenus/autosetup.js";

const STAFF_ROLES_TO_CREATE = [
  { name: "TYT Admin",       color: 0xff0000 as number, hoist: true },
  { name: "TYT Staff",       color: 0xff8800 as number, hoist: true },
  { name: "TYT High Tester", color: 0x9b59b6 as number, hoist: true },
  { name: "TYT Tester",      color: 0x3498db as number, hoist: true },
];

const TIER_ROLE_COLORS: Record<string, number> = {
  HT1: 0xff0000, HT2: 0xff2200, HT3: 0xff4400, HT4: 0xff6600, HT5: 0xff8800,
  MT1: 0xffaa00, MT2: 0xffbb00, MT3: 0xffcc00, MT4: 0xffdd00, MT5: 0xffee00,
  LT1: 0x00cc44, LT2: 0x00bb33, LT3: 0x00aa22, LT4: 0x009911, LT5: 0x008800,
  Unranked: 0x888888,
};

export const data = new SlashCommandBuilder()
  .setName("autosetup")
  .setDescription("Automatically create all TYT categories, channels, and roles — then guide you through full setup")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    await interaction.reply({ content: "❌ This command must be used in a server.", ephemeral: true });
    return;
  }

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!isAdmin(member)) {
    await interaction.reply({ content: "❌ You need **Administrator** permission to run autosetup.", ephemeral: true });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const created: string[] = [];
  const skipped: string[] = [];
  const guild = interaction.guild;

  async function getOrCreateCategory(name: string): Promise<CategoryChannel> {
    let cat = guild.channels.cache.find(
      (c) => c.name === name && c.type === ChannelType.GuildCategory,
    ) as CategoryChannel | undefined;
    if (!cat) {
      cat = await guild.channels.create({ name, type: ChannelType.GuildCategory });
      created.push(`📁 ${name}`);
    } else {
      skipped.push(`📁 ${name}`);
    }
    return cat;
  }

  async function getOrCreateTextChannel(name: string, parent: CategoryChannel): Promise<TextChannel> {
    let ch = guild.channels.cache.find(
      (c) => c.name === name && c.type === ChannelType.GuildText,
    ) as TextChannel | undefined;
    if (!ch) {
      ch = await guild.channels.create({ name, type: ChannelType.GuildText, parent: parent.id });
      created.push(`#${name}`);
    } else {
      skipped.push(`#${name}`);
    }
    return ch;
  }

  async function getOrCreateRole(name: string, color: number, hoist = false) {
    let role = guild.roles.cache.find((r) => r.name === name);
    if (!role) {
      role = await guild.roles.create({ name, color, hoist });
      created.push(`@${name}`);
    } else {
      skipped.push(`@${name}`);
    }
    return role;
  }

  try {
    // ── Categories ────────────────────────────────────────────────────────────
    const regCat     = await getOrCreateCategory("📋 Registration");
    const queueCat   = await getOrCreateCategory("⚔️ Queues");
    const resultsCat = await getOrCreateCategory("🏆 Results");
    const supportCat = await getOrCreateCategory("🎫 Support");
    const staffCat   = await getOrCreateCategory("🔒 Staff");

    // ── Channels ──────────────────────────────────────────────────────────────
    await getOrCreateTextChannel("request-test", regCat);
    await getOrCreateTextChannel("waitlist-info", regCat);

    for (const gm of GAMEMODES) {
      await getOrCreateTextChannel(GAMEMODE_CHANNEL_NAMES[gm], queueCat);
    }

    await getOrCreateTextChannel("results", resultsCat);
    await getOrCreateTextChannel("high-results", resultsCat);

    await getOrCreateTextChannel("support", supportCat);
    await getOrCreateTextChannel("leaderboards", supportCat);

    await getOrCreateTextChannel("tyt-logs", staffCat);
    await getOrCreateTextChannel("staff-chat", staffCat);

    // Lock staff-chat to staff only
    const staffRole = guild.roles.cache.find((r) => r.name === "TYT Staff") ??
      await guild.roles.create({ name: "TYT Staff", color: 0xff8800, hoist: true });
    const staffChatCh = guild.channels.cache.find((c) => c.name === "staff-chat") as TextChannel | undefined;
    if (staffChatCh) {
      await staffChatCh.permissionOverwrites.create(guild.roles.everyone, { ViewChannel: false });
      await staffChatCh.permissionOverwrites.create(staffRole, { ViewChannel: true });
    }

    // ── Roles ─────────────────────────────────────────────────────────────────
    for (const r of STAFF_ROLES_TO_CREATE) {
      await getOrCreateRole(r.name, r.color, r.hoist);
    }

    for (const tier of TIERS) {
      await getOrCreateRole(tier, TIER_ROLE_COLORS[tier] ?? 0x888888, false);
    }

    for (const gm of GAMEMODES) {
      await getOrCreateRole(GAMEMODE_WAITLIST_ROLES[gm], 0x5865f2, false);
    }

    // ── Summary then step 1 ───────────────────────────────────────────────────
    const createdCount  = created.length;
    const skippedCount  = skipped.length;

    const step1 = buildStep("reg");

    // Prepend summary embed before the step embed
    const summaryLines = [
      `✅ **${createdCount}** new items created, **${skippedCount}** already existed.`,
      "",
      "All channels, categories, and roles are ready.",
      "Now let's configure where to post each panel.",
    ];

    step1.embeds[0]!.setDescription(
      summaryLines.join("\n") + "\n\n" + (step1.embeds[0]!.data.description ?? ""),
    );

    await interaction.editReply(step1);
  } catch (err) {
    await interaction.editReply({
      content: `❌ Setup failed: ${err instanceof Error ? err.message : String(err)}`,
    });
  }
}
