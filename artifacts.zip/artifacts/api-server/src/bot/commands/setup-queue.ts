import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  ChannelType,
  type TextChannel,
} from "discord.js";
import { db } from "@workspace/db";
import { queueSessionsTable, queueEntriesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { buildQueueEmbed, buildQueueButtons } from "../embeds/queue.js";
import { isTester } from "../utils/permissions.js";
import { GAMEMODES, type Gamemode } from "../utils/gamemodes.js";
import { logAction } from "../utils/logger.js";

export const data = new SlashCommandBuilder()
  .setName("setup-queue")
  .setDescription("Open a testing queue session in this channel")
  .addStringOption((o) =>
    o
      .setName("gamemode")
      .setDescription("The gamemode for this queue")
      .setRequired(true)
      .addChoices(
        ...GAMEMODES.map((g) => ({ name: g, value: g })),
      ),
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild || !interaction.channel) {
    await interaction.reply({ content: "❌ This command must be used in a server channel.", ephemeral: true });
    return;
  }

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!isTester(member)) {
    await interaction.reply({ content: "❌ You need **TYT Tester** or higher to open a queue.", ephemeral: true });
    return;
  }

  const gamemode = interaction.options.getString("gamemode", true) as Gamemode;

  await interaction.deferReply({ ephemeral: true });

  // Check if there's already an open session for this gamemode
  const existing = await db.query.queueSessionsTable.findFirst({
    where: and(
      eq(queueSessionsTable.gamemode, gamemode),
      eq(queueSessionsTable.status, "open"),
    ),
  });

  if (existing) {
    await interaction.editReply({ content: `❌ A queue for **${gamemode}** is already open!` });
    return;
  }

  // Create the session
  const [session] = await db
    .insert(queueSessionsTable)
    .values({
      gamemode,
      testerId: interaction.user.id,
      status: "open",
      channelId: interaction.channelId,
    })
    .returning();

  if (!session) {
    await interaction.editReply({ content: "❌ Failed to create queue session." });
    return;
  }

  const embed = buildQueueEmbed(gamemode, [], interaction.user.id, true, new Date());
  const buttons = buildQueueButtons(gamemode, true);

  // Ping the waitlist role
  const waitlistRole = interaction.guild.roles.cache.find(
    (r) => r.name === `Waitlist [${gamemode}]`,
  );
  const pingContent = waitlistRole ? `${waitlistRole} — A tester is now available for **${gamemode}**!` : undefined;

  const msg = await (interaction.channel as TextChannel).send({
    content: pingContent,
    embeds: [embed],
    components: buttons,
  });

  await db
    .update(queueSessionsTable)
    .set({ messageId: msg.id })
    .where(eq(queueSessionsTable.id, session.id));

  await logAction(interaction.guild, "Queue Opened", interaction.user.id, `${gamemode} by ${interaction.user.tag}`);
  await interaction.editReply({ content: `✅ **${gamemode}** queue opened! Session ID: \`${session.id}\`` });
}
