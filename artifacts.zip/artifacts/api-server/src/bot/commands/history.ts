import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { db } from "@workspace/db";
import { usersTable, matchResultsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { COLORS } from "../embeds/colors.js";
import { getTierColor } from "../utils/tiers.js";
import { GAMEMODE_EMOJIS, type Gamemode } from "../utils/gamemodes.js";

export const data = new SlashCommandBuilder()
  .setName("history")
  .setDescription("View the last 10 tier test results for a player")
  .addUserOption((o) =>
    o.setName("player").setDescription("Player to view history for (defaults to yourself)").setRequired(false),
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    await interaction.reply({ content: "❌ Server only.", ephemeral: true });
    return;
  }

  await interaction.deferReply({ ephemeral: false });

  const target = interaction.options.getUser("player") ?? interaction.user;

  const record = await db.query.usersTable.findFirst({
    where: eq(usersTable.discordId, target.id),
  });

  if (!record) {
    await interaction.editReply({
      content: target.id === interaction.user.id
        ? "❌ You are not registered. Click **Register** in the registration panel first."
        : `❌ <@${target.id}> is not registered.`,
    });
    return;
  }

  const results = await db.query.matchResultsTable.findMany({
    where: eq(matchResultsTable.playerId, target.id),
    orderBy: [desc(matchResultsTable.createdAt)],
    limit: 10,
  });

  if (results.length === 0) {
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.DARK)
          .setTitle(`📜 Match History — ${record.ign}`)
          .setDescription("No test results yet.")
          .setTimestamp(),
      ],
    });
    return;
  }

  const emoji = (gm: string) => GAMEMODE_EMOJIS[gm as Gamemode] ?? "🎮";

  const fields = results.map((r, i) => {
    const ts   = Math.floor(new Date(r.createdAt).getTime() / 1000);
    const icon = r.outcome === "tested" ? "📝" : "📋";
    return {
      name: `${i + 1}. ${emoji(r.gamemode)} ${r.gamemode} — ${r.previousTier} → **${r.newTier}**`,
      value:
        `${icon} **Score:** ${r.score}` +
        (r.notes ? ` · *${r.notes}*` : "") +
        `\n👤 Tested by <@${r.testerId}> · <t:${ts}:R>`,
      inline: false,
    };
  });

  const winRate = record.totalTests > 0
    ? ((record.wins / record.totalTests) * 100).toFixed(1)
    : "0.0";

  const embed = new EmbedBuilder()
    .setColor(getTierColor(record.currentTier))
    .setTitle(`📜 Match History — ${record.ign}`)
    .setDescription(
      `**Tier:** ${record.currentTier} · **Points:** ${record.points}\n` +
      `**Record:** ${record.wins}W / ${record.losses}L · **Win Rate:** ${winRate}%\n` +
      `Showing last **${results.length}** result${results.length !== 1 ? "s" : ""}`,
    )
    .addFields(fields)
    .setFooter({ text: `Discord: ${target.username}` })
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}
