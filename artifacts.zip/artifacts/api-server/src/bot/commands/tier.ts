import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { COLORS } from "../embeds/colors.js";
import { TIERS, TIER_DISPLAY, TIER_POINTS, getTierColor } from "../utils/tiers.js";

export const data = new SlashCommandBuilder()
  .setName("tier")
  .setDescription("View tier information and the full tier table")
  .addSubcommand((sub) =>
    sub.setName("list").setDescription("Show the full tier table with point values"),
  )
  .addSubcommand((sub) =>
    sub
      .setName("info")
      .setDescription("Show detailed info about a specific tier")
      .addStringOption((o) =>
        o.setName("tier").setDescription("The tier to look up").setRequired(true)
          .addChoices(...TIERS.map((t) => ({ name: t, value: t }))),
      ),
  );

const TIER_DESCRIPTIONS: Record<string, string> = {
  HT1: "The absolute elite of Minecraft PvP. Reserved for the very best players who consistently dominate at the highest level. Extremely rare.",
  HT2: "Top-tier competitive players with dominant skill sets and near-perfect mechanics. One of the hardest tiers to achieve.",
  HT3: "Very strong players with excellent mechanics and game sense. Regularly outperform most competition.",
  HT4: "High-skilled players who can compete with top tiers. Strong fundamentals and game sense.",
  HT5: "Entry to High Tier. Highly skilled with good mechanics and above-average game sense.",
  MT1: "The top of Mid Tier — very consistent, strong players who are close to HT level.",
  MT2: "Strong mid-tier players with solid mechanics and decent game sense.",
  MT3: "The heart of Mid Tier. Consistent players who understand the game well.",
  MT4: "Lower mid-tier with improving mechanics and developing game sense.",
  MT5: "Entry to Mid Tier. Shows clear improvement beyond Low Tier with developing skills.",
  LT1: "Top of Low Tier — players with solid basics who are working toward MT.",
  LT2: "Good foundational players with clear understanding of PvP basics.",
  LT3: "Players who understand the fundamentals but have room to improve.",
  LT4: "Developing players who are starting to grasp PvP mechanics.",
  LT5: "Entry-level tier. Basic PvP understanding with room for significant improvement.",
  Unranked: "Not yet tested by a TYT tester. Join a queue in your desired gamemode to get ranked!",
};

export async function execute(interaction: ChatInputCommandInteraction) {
  const sub = interaction.options.getSubcommand(true);

  // ── /tier list ──────────────────────────────────────────────────────────────
  if (sub === "list") {
    const htLines = ["HT1", "HT2", "HT3", "HT4", "HT5"].map((t) =>
      `\`${t.padEnd(4)}\` ${TIER_DISPLAY[t]} — **${TIER_POINTS[t]}pts**`,
    ).join("\n");

    const mtLines = ["MT1", "MT2", "MT3", "MT4", "MT5"].map((t) =>
      `\`${t.padEnd(4)}\` ${TIER_DISPLAY[t]} — **${TIER_POINTS[t]}pts**`,
    ).join("\n");

    const ltLines = ["LT1", "LT2", "LT3", "LT4", "LT5"].map((t) =>
      `\`${t.padEnd(4)}\` ${TIER_DISPLAY[t]} — **${TIER_POINTS[t]}pts**`,
    ).join("\n");

    const embed = new EmbedBuilder()
      .setColor(COLORS.TYT)
      .setTitle("🏆 TestYourTier — Full Tier Table")
      .setDescription(
        "Tiers represent your skill level across Minecraft PvP gamemodes.\n" +
        "Points are used for leaderboard rankings.",
      )
      .addFields(
        { name: "🔴 High Tier (HT)",  value: htLines, inline: true },
        { name: "🟠 Mid Tier (MT)",   value: mtLines, inline: true },
        { name: "🟢 Low Tier (LT)",   value: ltLines, inline: true },
        {
          name: "⚪ Unranked — 0pts",
          value: "Not yet tested. Join a queue to get ranked!",
          inline: false,
        },
        {
          name: "ℹ️ How Tiers Work",
          value:
            "• A **TYT Tester** tests you in your chosen gamemode via a private 1v1\n" +
            "• After the test, the tester submits a result assigning you a tier\n" +
            "• Your tier role and points update automatically\n" +
            "• Join the waitlist via the registration panel to be notified when a queue opens\n" +
            "• Use `/tier info [tier]` to learn about a specific tier",
          inline: false,
        },
      )
      .setFooter({ text: "TestYourTier" });

    await interaction.reply({ embeds: [embed], ephemeral: false });
    return;
  }

  // ── /tier info ──────────────────────────────────────────────────────────────
  if (sub === "info") {
    const tier = interaction.options.getString("tier", true);
    const points = TIER_POINTS[tier] ?? 0;
    const displayName = TIER_DISPLAY[tier] ?? tier;
    const description = TIER_DESCRIPTIONS[tier] ?? "No description available.";
    const color = getTierColor(tier);

    const group = tier === "Unranked" ? "Unranked" :
      tier.startsWith("HT") ? "High Tier 🔴" :
      tier.startsWith("MT") ? "Mid Tier 🟠" :
      "Low Tier 🟢";

    // Neighbouring tiers
    const idx = TIERS.indexOf(tier as (typeof TIERS)[number]);
    const above = idx > 0 ? TIERS[idx - 1] : null;
    const below = idx < TIERS.length - 1 ? TIERS[idx + 1] : null;

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(`🏆 Tier: ${displayName} (${tier})`)
      .addFields(
        { name: "Group",       value: group,                                           inline: true },
        { name: "Points",      value: `**${points}** pts`,                             inline: true },
        { name: "\u200b",      value: "\u200b",                                        inline: true },
        { name: "Above this",  value: above  ? `${above} (${TIER_POINTS[above]}pts)` : "— (Top tier)", inline: true },
        { name: "Below this",  value: below  ? `${below} (${TIER_POINTS[below]}pts)` : "— (Unranked)", inline: true },
        { name: "\u200b",      value: "\u200b",                                        inline: true },
        { name: "Description", value: description, inline: false },
        {
          name: "How to reach this tier",
          value:
            `1. Register your profile in the registration panel\n` +
            `2. Join the waitlist for your preferred gamemode\n` +
            `3. Wait for a tester to open a queue\n` +
            `4. Join the queue and get tested\n` +
            `5. A tester will assign you a tier based on your performance`,
          inline: false,
        },
      )
      .setFooter({ text: "TestYourTier" });

    await interaction.reply({ embeds: [embed], ephemeral: false });
    return;
  }

  await interaction.reply({ content: "❌ Unknown subcommand.", ephemeral: true });
}
