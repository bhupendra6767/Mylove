import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { ilike, desc } from "drizzle-orm";
import { COLORS } from "../embeds/colors.js";
import { getTierColor } from "../utils/tiers.js";

export const data = new SlashCommandBuilder()
  .setName("search")
  .setDescription("Search for a registered player by their Minecraft IGN")
  .addStringOption((o) =>
    o.setName("ign").setDescription("IGN to search for (partial match supported)").setRequired(true),
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply({ ephemeral: false });

  const query = interaction.options.getString("ign", true).trim();

  if (query.length < 2) {
    await interaction.editReply({ content: "❌ Search term must be at least 2 characters." });
    return;
  }

  const results = await db.query.usersTable.findMany({
    where: ilike(usersTable.ign, `%${query}%`),
    orderBy: [desc(usersTable.points)],
    limit: 10,
  });

  if (results.length === 0) {
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.DARK)
          .setTitle(`🔍 Search: "${query}"`)
          .setDescription(`No registered players found matching **${query}**.`)
          .setTimestamp(),
      ],
    });
    return;
  }

  const fields = results.map((p, i) => {
    const winRate = p.totalTests > 0 ? ((p.wins / p.totalTests) * 100).toFixed(0) : "0";
    return {
      name: `${i + 1}. ${p.ign}`,
      value:
        `🏆 **${p.currentTier}** · ${p.points}pts\n` +
        `👤 <@${p.discordId}> · ${p.accountType}\n` +
        `📊 ${p.wins}W/${p.losses}L (${winRate}% WR) · ${p.totalTests} tests`,
      inline: results.length > 3 ? true : false,
    };
  });

  const embed = new EmbedBuilder()
    .setColor(results.length === 1 ? getTierColor(results[0]!.currentTier) : COLORS.PRIMARY)
    .setTitle(`🔍 Search Results: "${query}"`)
    .setDescription(`Found **${results.length}** player${results.length !== 1 ? "s" : ""}`)
    .addFields(fields)
    .setFooter({ text: "TestYourTier · Use /profile @user for full details" })
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}
