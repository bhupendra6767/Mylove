import { SlashCommandBuilder, type ChatInputCommandInteraction } from "discord.js";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { buildLeaderboardEmbed, buildLeaderboardButtons, type LeaderboardType } from "../embeds/leaderboard.js";

export const data = new SlashCommandBuilder()
  .setName("leaderboard")
  .setDescription("View the TestYourTier leaderboard")
  .addStringOption((o) =>
    o
      .setName("type")
      .setDescription("Leaderboard category")
      .setRequired(false)
      .addChoices(
        { name: "Points",     value: "points" },
        { name: "Wins",       value: "wins" },
        { name: "Win Streak", value: "winstreak" },
        { name: "Activity",   value: "activity" },
      ),
  )
  .addStringOption((o) =>
    o
      .setName("gamemode")
      .setDescription("Filter by gamemode (default: Overall)")
      .setRequired(false)
      .addChoices(
        { name: "Overall",       value: "Overall" },
        { name: "Axe & Shield",  value: "Axe & Shield" },
        { name: "Neth Pot",      value: "Neth Pot" },
        { name: "Dia Pot",       value: "Dia Pot" },
        { name: "SMP Kit",       value: "SMP Kit" },
        { name: "Mace",          value: "Mace" },
        { name: "Sword",         value: "Sword" },
        { name: "UHC",           value: "UHC" },
        { name: "CPvP",          value: "CPvP" },
      ),
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply();

  const type = (interaction.options.getString("type") ?? "points") as LeaderboardType;
  const gamemode = interaction.options.getString("gamemode") ?? "Overall";

  const orderCol =
    type === "points"    ? usersTable.points :
    type === "wins"      ? usersTable.wins :
    type === "winstreak" ? usersTable.winStreak :
                           usersTable.totalTests;

  const users =
    gamemode !== "Overall"
      ? await db.select().from(usersTable).where(eq(usersTable.currentGamemode, gamemode)).orderBy(desc(orderCol))
      : await db.select().from(usersTable).orderBy(desc(orderCol));

  const embed = buildLeaderboardEmbed(users, type, 0, gamemode);
  const components = buildLeaderboardButtons(type, 0, gamemode, users.length);

  await interaction.editReply({ embeds: [embed], components });
}
