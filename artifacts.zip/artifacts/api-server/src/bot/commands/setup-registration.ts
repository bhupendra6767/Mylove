import { SlashCommandBuilder, type ChatInputCommandInteraction, type TextChannel } from "discord.js";
import { buildRegistrationEmbed, buildRegisterButton, buildWaitlistSelect } from "../embeds/registration.js";
import { isStaff } from "../utils/permissions.js";

export const data = new SlashCommandBuilder()
  .setName("setup-registration")
  .setDescription("Post the TestYourTier registration panel in this channel");

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild || !interaction.member) {
    await interaction.reply({ content: "❌ This command must be used in a server.", ephemeral: true });
    return;
  }

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!isStaff(member)) {
    await interaction.reply({ content: "❌ You need **TYT Staff** or higher to use this command.", ephemeral: true });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const embed = buildRegistrationEmbed();
  const registerBtn = buildRegisterButton();
  const waitlistSelect = buildWaitlistSelect();

  await (interaction.channel as TextChannel).send({ embeds: [embed], components: [registerBtn, waitlistSelect] });
  await interaction.editReply({ content: "✅ Registration panel posted successfully." });
}
