import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { db } from "@workspace/db";
import { usersTable, matchResultsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { COLORS } from "../embeds/colors.js";
import { TIERS, TIER_POINTS, TIER_DISPLAY, getTierColor } from "../utils/tiers.js";
import { isStaff } from "../utils/permissions.js";
import { logAction } from "../utils/logger.js";

export const data = new SlashCommandBuilder()
  .setName("mod")
  .setDescription("Staff moderation tools for player and queue management")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
  .addSubcommandGroup((group) =>
    group
      .setName("tier")
      .setDescription("Tier management")
      .addSubcommand((sub) =>
        sub
          .setName("set")
          .setDescription("Force-assign a tier to a player")
          .addUserOption((o) => o.setName("player").setDescription("The player to assign a tier to").setRequired(true))
          .addStringOption((o) =>
            o.setName("tier").setDescription("Tier to assign").setRequired(true)
              .addChoices(...TIERS.map((t) => ({ name: t, value: t }))),
          ),
      )
      .addSubcommand((sub) =>
        sub
          .setName("remove")
          .setDescription("Strip a player's tier and reset them to Unranked")
          .addUserOption((o) => o.setName("player").setDescription("The player to reset").setRequired(true)),
      ),
  )
  .addSubcommandGroup((group) =>
    group
      .setName("queue")
      .setDescription("Queue ban management")
      .addSubcommand((sub) =>
        sub
          .setName("ban")
          .setDescription("Ban a player from joining any queue")
          .addUserOption((o) => o.setName("player").setDescription("The player to ban").setRequired(true))
          .addStringOption((o) => o.setName("reason").setDescription("Reason for the queue ban").setRequired(true)),
      )
      .addSubcommand((sub) =>
        sub
          .setName("unban")
          .setDescription("Unban a player from queues")
          .addUserOption((o) => o.setName("player").setDescription("The player to unban").setRequired(true)),
      ),
  )
  .addSubcommandGroup((group) =>
    group
      .setName("player")
      .setDescription("Player management")
      .addSubcommand((sub) =>
        sub
          .setName("info")
          .setDescription("View detailed staff info about a player")
          .addUserOption((o) => o.setName("player").setDescription("The player to look up").setRequired(true)),
      )
      .addSubcommand((sub) =>
        sub
          .setName("reset")
          .setDescription("Wipe ALL stats and reset tier to Unranked — irreversible")
          .addUserOption((o) => o.setName("player").setDescription("The player to full-reset").setRequired(true)),
      ),
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    await interaction.reply({ content: "❌ Server only.", ephemeral: true });
    return;
  }

  const mod = await interaction.guild.members.fetch(interaction.user.id);
  if (!isStaff(mod)) {
    await interaction.reply({ content: "❌ You need **TYT Staff** or higher.", ephemeral: true });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const group = interaction.options.getSubcommandGroup(true);
  const sub   = interaction.options.getSubcommand(true);

  // ── /mod tier set ─────────────────────────────────────────────────────────
  if (group === "tier" && sub === "set") {
    const target = interaction.options.getUser("player", true);
    const tier   = interaction.options.getString("tier", true);

    const record = await db.query.usersTable.findFirst({
      where: eq(usersTable.discordId, target.id),
    });
    if (!record) {
      await interaction.editReply({ content: `❌ <@${target.id}> is not registered.` });
      return;
    }

    const prevTier = record.currentTier;
    const newPoints = TIER_POINTS[tier] ?? 0;

    await db.update(usersTable).set({
      currentTier: tier,
      points: newPoints,
      updatedAt: new Date(),
    }).where(eq(usersTable.discordId, target.id));

    // Update Discord roles
    try {
      const member = await interaction.guild.members.fetch(target.id);
      for (const t of TIERS) {
        const role = interaction.guild.roles.cache.find((r) => r.name === t);
        if (role && member.roles.cache.has(role.id)) await member.roles.remove(role);
      }
      const newRole = interaction.guild.roles.cache.find((r) => r.name === tier);
      if (newRole) await member.roles.add(newRole);
    } catch { /* member may have left */ }

    await logAction(interaction.guild, "Mod: Tier Set", target.id,
      `${prevTier} → ${tier} | by ${interaction.user.tag}`);

    const embed = new EmbedBuilder()
      .setColor(getTierColor(tier))
      .setTitle("✅ Tier Updated")
      .addFields(
        { name: "Player",     value: `<@${target.id}>`,          inline: true },
        { name: "Old Tier",   value: prevTier,                    inline: true },
        { name: "New Tier",   value: `${tier} (${TIER_DISPLAY[tier] ?? tier})`, inline: true },
        { name: "Points",     value: `${newPoints} pts`,          inline: true },
        { name: "Updated by", value: `<@${interaction.user.id}>`, inline: true },
      )
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
    return;
  }

  // ── /mod tier remove ──────────────────────────────────────────────────────
  if (group === "tier" && sub === "remove") {
    const target = interaction.options.getUser("player", true);

    const record = await db.query.usersTable.findFirst({
      where: eq(usersTable.discordId, target.id),
    });
    if (!record) {
      await interaction.editReply({ content: `❌ <@${target.id}> is not registered.` });
      return;
    }

    const prevTier = record.currentTier;
    await db.update(usersTable).set({
      currentTier: "Unranked",
      points: 0,
      updatedAt: new Date(),
    }).where(eq(usersTable.discordId, target.id));

    try {
      const member = await interaction.guild.members.fetch(target.id);
      for (const t of TIERS) {
        const role = interaction.guild.roles.cache.find((r) => r.name === t);
        if (role && member.roles.cache.has(role.id)) await member.roles.remove(role);
      }
      const unrankedRole = interaction.guild.roles.cache.find((r) => r.name === "Unranked");
      if (unrankedRole) await member.roles.add(unrankedRole);
    } catch { /* member may have left */ }

    await logAction(interaction.guild, "Mod: Tier Removed", target.id,
      `${prevTier} → Unranked | by ${interaction.user.tag}`);

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.WARNING)
          .setTitle("⚠️ Tier Removed")
          .setDescription(`<@${target.id}> has been reset from **${prevTier}** to **Unranked**.`)
          .setTimestamp(),
      ],
    });
    return;
  }

  // ── /mod queue ban ─────────────────────────────────────────────────────────
  if (group === "queue" && sub === "ban") {
    const target = interaction.options.getUser("player", true);
    const reason = interaction.options.getString("reason", true);

    const record = await db.query.usersTable.findFirst({
      where: eq(usersTable.discordId, target.id),
    });
    if (!record) {
      await interaction.editReply({ content: `❌ <@${target.id}> is not registered.` });
      return;
    }

    if (record.queueBanned) {
      await interaction.editReply({ content: `⚠️ <@${target.id}> is already queue-banned.` });
      return;
    }

    await db.update(usersTable).set({
      queueBanned: true,
      queueBannedReason: reason,
      updatedAt: new Date(),
    }).where(eq(usersTable.discordId, target.id));

    await logAction(interaction.guild, "Mod: Queue Ban", target.id,
      `Reason: ${reason} | by ${interaction.user.tag}`);

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.ERROR)
          .setTitle("🔨 Queue Ban Applied")
          .addFields(
            { name: "Player", value: `<@${target.id}>`,          inline: true },
            { name: "Banned by", value: `<@${interaction.user.id}>`, inline: true },
            { name: "Reason", value: reason, inline: false },
          )
          .setTimestamp(),
      ],
    });
    return;
  }

  // ── /mod queue unban ──────────────────────────────────────────────────────
  if (group === "queue" && sub === "unban") {
    const target = interaction.options.getUser("player", true);

    const record = await db.query.usersTable.findFirst({
      where: eq(usersTable.discordId, target.id),
    });
    if (!record) {
      await interaction.editReply({ content: `❌ <@${target.id}> is not registered.` });
      return;
    }

    if (!record.queueBanned) {
      await interaction.editReply({ content: `⚠️ <@${target.id}> is not queue-banned.` });
      return;
    }

    await db.update(usersTable).set({
      queueBanned: false,
      queueBannedReason: null,
      updatedAt: new Date(),
    }).where(eq(usersTable.discordId, target.id));

    await logAction(interaction.guild, "Mod: Queue Unban", target.id,
      `Unbanned by ${interaction.user.tag}`);

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.SUCCESS)
          .setTitle("✅ Queue Ban Removed")
          .setDescription(`<@${target.id}> can now join queues again.`)
          .setTimestamp(),
      ],
    });
    return;
  }

  // ── /mod player info ──────────────────────────────────────────────────────
  if (group === "player" && sub === "info") {
    const target = interaction.options.getUser("player", true);

    const record = await db.query.usersTable.findFirst({
      where: eq(usersTable.discordId, target.id),
    });
    if (!record) {
      await interaction.editReply({ content: `❌ <@${target.id}> is not registered.` });
      return;
    }

    const recentResults = await db.query.matchResultsTable.findMany({
      where: eq(matchResultsTable.playerId, target.id),
      orderBy: [desc(matchResultsTable.createdAt)],
      limit: 5,
    });

    const winRate = record.totalTests > 0
      ? ((record.wins / record.totalTests) * 100).toFixed(1)
      : "0.0";

    const resultLines = recentResults.length > 0
      ? recentResults.map((r) =>
          `• **${r.gamemode}** — ${r.score} — ${r.previousTier}→**${r.newTier}** <t:${Math.floor(new Date(r.createdAt).getTime() / 1000)}:R>`,
        ).join("\n")
      : "No results yet.";

    const embed = new EmbedBuilder()
      .setColor(getTierColor(record.currentTier))
      .setTitle(`🔍 Staff Info — ${record.ign}`)
      .addFields(
        { name: "Discord",       value: `<@${record.discordId}>`,    inline: true },
        { name: "IGN",           value: record.ign,                  inline: true },
        { name: "Account",       value: record.accountType,          inline: true },
        { name: "Current Tier",  value: record.currentTier,          inline: true },
        { name: "Points",        value: `${record.points}`,          inline: true },
        { name: "Win Rate",      value: `${winRate}%`,               inline: true },
        { name: "W / L",         value: `${record.wins} / ${record.losses}`, inline: true },
        { name: "Win Streak",    value: `${record.winStreak}`,       inline: true },
        { name: "Total Tests",   value: `${record.totalTests}`,      inline: true },
        { name: "Queue Banned",  value: record.queueBanned ? `🔨 Yes — ${record.queueBannedReason ?? "No reason"}` : "✅ No", inline: false },
        { name: "Registered",    value: `<t:${Math.floor(new Date(record.createdAt).getTime() / 1000)}:F>`, inline: false },
        { name: "Last 5 Results", value: resultLines, inline: false },
      )
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
    return;
  }

  // ── /mod player reset ─────────────────────────────────────────────────────
  if (group === "player" && sub === "reset") {
    const target = interaction.options.getUser("player", true);

    const record = await db.query.usersTable.findFirst({
      where: eq(usersTable.discordId, target.id),
    });
    if (!record) {
      await interaction.editReply({ content: `❌ <@${target.id}> is not registered.` });
      return;
    }

    await db.update(usersTable).set({
      currentTier: "Unranked",
      wins: 0,
      losses: 0,
      points: 0,
      winStreak: 0,
      totalTests: 0,
      queueBanned: false,
      queueBannedReason: null,
      updatedAt: new Date(),
    }).where(eq(usersTable.discordId, target.id));

    try {
      const member = await interaction.guild.members.fetch(target.id);
      for (const t of TIERS) {
        const role = interaction.guild.roles.cache.find((r) => r.name === t);
        if (role && member.roles.cache.has(role.id)) await member.roles.remove(role);
      }
      const unrankedRole = interaction.guild.roles.cache.find((r) => r.name === "Unranked");
      if (unrankedRole) await member.roles.add(unrankedRole);
    } catch { /* member may have left */ }

    await logAction(interaction.guild, "Mod: Player Reset", target.id,
      `Full reset by ${interaction.user.tag}`);

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.ERROR)
          .setTitle("🗑️ Player Fully Reset")
          .setDescription(
            `<@${target.id}> (**${record.ign}**) has been fully reset.\n` +
            `All stats wiped, tier set to Unranked.`,
          )
          .setTimestamp(),
      ],
    });
    return;
  }

  await interaction.editReply({ content: "❌ Unknown subcommand." });
}
