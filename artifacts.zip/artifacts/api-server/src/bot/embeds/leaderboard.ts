import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } from "discord.js";
import { COLORS, TYT_FOOTER } from "./colors.js";
import { getTierDisplayName } from "../utils/tiers.js";
import type { User } from "@workspace/db";

const PAGE_SIZE = 25;

export type LeaderboardType = "points" | "wins" | "winstreak" | "activity";

export function buildLeaderboardEmbed(
  users: User[],
  type: LeaderboardType,
  page: number,
  gamemode?: string,
) {
  const total = users.length;
  const start = page * PAGE_SIZE;
  const slice = users.slice(start, start + PAGE_SIZE);

  const typeLabels: Record<LeaderboardType, string> = {
    points:    "🏆 Points Leaderboard",
    wins:      "✅ Wins Leaderboard",
    winstreak: "🔥 Win Streak Leaderboard",
    activity:  "📊 Activity Leaderboard",
  };

  const lines = slice.map((u, i) => {
    const rank = start + i + 1;
    const tier = getTierDisplayName(u.currentTier);
    const value =
      type === "points"    ? u.points :
      type === "wins"      ? u.wins :
      type === "winstreak" ? u.winStreak :
                             u.totalTests;
    const medal = rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : `**${rank}.**`;
    return `${medal} ${u.ign} — ${tier} (${value} ${type === "activity" ? "tests" : type === "winstreak" ? "streak" : type})`;
  });

  const embed = new EmbedBuilder()
    .setColor(COLORS.TYT)
    .setTitle(`🏆 TestYourTier Leaderboard`)
    .setDescription(lines.length > 0 ? lines.join("\n") : "*No players ranked yet.*")
    .addFields({
      name: "🎮 Gamemode",
      value: gamemode ?? "Overall",
      inline: false,
    })
    .setFooter({ text: `${TYT_FOOTER} | Page ${page + 1} of ${Math.max(1, Math.ceil(total / PAGE_SIZE))}` })
    .setTimestamp();

  return embed;
}

export function buildLeaderboardButtons(type: LeaderboardType, page: number, gamemode: string, total: number) {
  const maxPage = Math.max(0, Math.ceil(total / PAGE_SIZE) - 1);
  const safe = gamemode.replace(/[^a-z0-9]/gi, "_");

  const navRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`tyt_lb_prev_${type}_${page}_${safe}`)
      .setLabel("◀ Previous")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 0),
    new ButtonBuilder()
      .setCustomId(`tyt_lb_next_${type}_${page}_${safe}`)
      .setLabel("▶ Next")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= maxPage),
  );

  const gmRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`tyt_lb_gamemode_${type}_${page}`)
      .setPlaceholder("Filter by gamemode")
      .addOptions([
        { label: "Overall",       value: "Overall",      default: gamemode === "Overall" },
        { label: "Axe & Shield",  value: "Axe & Shield", emoji: "🪓", default: gamemode === "Axe & Shield" },
        { label: "Neth Pot",      value: "Neth Pot",     emoji: "🧪", default: gamemode === "Neth Pot" },
        { label: "Dia Pot",       value: "Dia Pot",      emoji: "💎", default: gamemode === "Dia Pot" },
        { label: "SMP Kit",       value: "SMP Kit",      emoji: "🌿", default: gamemode === "SMP Kit" },
        { label: "Mace",          value: "Mace",         emoji: "🔨", default: gamemode === "Mace" },
        { label: "Sword",         value: "Sword",        emoji: "⚔️", default: gamemode === "Sword" },
        { label: "UHC",           value: "UHC",          emoji: "🌍", default: gamemode === "UHC" },
        { label: "CPvP",          value: "CPvP",         emoji: "💥", default: gamemode === "CPvP" },
      ]),
  );

  return [navRow, gmRow];
}
