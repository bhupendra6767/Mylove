import { EmbedBuilder } from "discord.js";
import { getTierColor, getTierDisplayName } from "../utils/tiers.js";
import { TYT_FOOTER, TYT_WEBSITE } from "./colors.js";
import type { User } from "@workspace/db";

export function buildProfileEmbed(user: User, discordTag: string) {
  const winRate =
    user.totalTests > 0
      ? `${Math.round((user.wins / user.totalTests) * 100)}%`
      : "N/A";

  const avatarUrl =
    user.accountType === "cracked" && user.skinUrl
      ? user.skinUrl
      : `https://mc-heads.net/avatar/${encodeURIComponent(user.ign)}/128`;

  return new EmbedBuilder()
    .setColor(getTierColor(user.currentTier))
    .setTitle(`🏆 ${user.ign} — Profile`)
    .setThumbnail(avatarUrl)
    .addFields(
      { name: "👤 IGN",          value: user.ign,                                   inline: true },
      { name: "🏅 Tier",         value: getTierDisplayName(user.currentTier),         inline: true },
      { name: "🎮 Gamemode",     value: user.currentGamemode ?? "None",               inline: true },
      { name: "✅ Wins",          value: String(user.wins),                           inline: true },
      { name: "❌ Losses",        value: String(user.losses),                         inline: true },
      { name: "📊 Win Rate",      value: winRate,                                    inline: true },
      { name: "📈 Total Tests",   value: String(user.totalTests),                    inline: true },
      { name: "🔥 Win Streak",   value: String(user.winStreak),                     inline: true },
      { name: "🖥️ Account Type", value: user.accountType === "premium" ? "Premium (Official)" : "Cracked", inline: true },
      {
        name: "📅 Registered",
        value: `<t:${Math.floor(new Date(user.createdAt).getTime() / 1000)}:D>`,
        inline: false,
      },
    )
    .setFooter({ text: TYT_FOOTER, iconURL: undefined })
    .setTimestamp();
}
