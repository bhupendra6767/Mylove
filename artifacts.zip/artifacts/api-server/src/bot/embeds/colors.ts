export const COLORS = {
  PRIMARY: 0x5865f2,
  SUCCESS: 0x57f287,
  ERROR: 0xed4245,
  WARNING: 0xfee75c,
  INFO: 0x5865f2,
  DARK: 0x2b2d31,
  TYT: 0x7c3aed,
  QUEUE: 0x3b82f6,
  RESULT: 0xf59e0b,
  TICKET: 0x10b981,
} as const;

export const TYT_BRAND = "TestYourTier";
export const TYT_WEBSITE = "https://tyt.netlify.app/";
export const TYT_FOOTER = "TestYourTier";
