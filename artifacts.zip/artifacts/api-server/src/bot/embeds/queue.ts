import {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import { COLORS, TYT_FOOTER } from "./colors.js";
import { GAMEMODE_EMOJIS, type Gamemode } from "../utils/gamemodes.js";

export interface QueueEntry {
  userId: string;
  username: string;
  position: number;
}

export function buildQueueEmbed(
  gamemode: Gamemode,
  entries: QueueEntry[],
  testerTag: string,
  isOpen: boolean,
  sessionOpenedAt?: Date,
) {
  const emoji = GAMEMODE_EMOJIS[gamemode] ?? "⚔️";
  const embed = new EmbedBuilder()
    .setColor(isOpen ? COLORS.QUEUE : COLORS.ERROR)
    .setTitle(`${emoji} ${gamemode} Queue ${isOpen ? "— Open" : "— Closed"}`)
    .setFooter({ text: TYT_FOOTER });

  if (!isOpen) {
    embed
      .setTitle(`🔒 ${gamemode} Queue Closed`)
      .setDescription(
        "This testing session has ended. You will be notified here when a new queue opens.\n\n" +
        `📋 **Reason**\nQueue manually ended by command\n\n` +
        `⏰ **Session Ended**\n${sessionOpenedAt ? `<t:${Math.floor(sessionOpenedAt.getTime() / 1000)}:F>` : "Unknown"}\n\n` +
        "Thank you for testing!",
      )
      .setTimestamp();
    return embed;
  }

  embed
    .setDescription(
      `Being in the waitlist simply means you are waiting to be tested at some point, it does not mean you are immediately going to be tested right away. Please be patient!\n\n` +
      `The queue is what you join once you are ready to actually test. When a tester for this gamemode becomes available, @here will be pinged with a button to join the queue.\n\n` +
      `If you decide no longer want to be tested, press the **leave** button.`,
    )
    .addFields(
      {
        name: "🎮 Tester",
        value: `<@${testerTag}>`,
        inline: true,
      },
      {
        name: "👥 Queue",
        value: entries.length > 0
          ? entries
              .sort((a, b) => a.position - b.position)
              .map((e, i) => `**${i + 1}.** <@${e.userId}>`)
              .join("\n")
          : "*Empty — be the first to join!*",
        inline: false,
      },
    )
    .setTimestamp();

  return embed;
}

export function buildQueueButtons(gamemode: string, isTester = false) {
  const safe = gamemode.replace(/[^a-z0-9]/gi, "_");
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`tyt_queue_join_${safe}`)
      .setLabel("Join")
      .setStyle(ButtonStyle.Success)
      .setEmoji("✅"),
    new ButtonBuilder()
      .setCustomId(`tyt_queue_leave_${safe}`)
      .setLabel("Leave")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("📋"),
    new ButtonBuilder()
      .setCustomId(`tyt_queue_next_${safe}`)
      .setLabel("Next")
      .setStyle(ButtonStyle.Primary)
      .setEmoji("⏭️"),
    new ButtonBuilder()
      .setCustomId(`tyt_queue_close_${safe}`)
      .setLabel("Close")
      .setStyle(ButtonStyle.Danger)
      .setEmoji("🔒"),
  );
  return [row];
}
