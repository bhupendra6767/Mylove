import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import { COLORS, TYT_FOOTER } from "./colors.js";

export function buildSupportPortalEmbed() {
  return new EmbedBuilder()
    .setColor(COLORS.TICKET)
    .setTitle("🎫 Support Portal")
    .setDescription(
      "You can create a ticket for the following:\n\n" +
      "1) General Support\n" +
      "2) Player Reporting\n" +
      "3) Staff Reporting\n" +
      "4) Applying for staff\n" +
      "5) Applying for tester\n" +
      "6) Apply for High Test\n\n" +
      "Please select the corresponding button category below to begin.",
    )
    .setFooter({ text: TYT_FOOTER })
    .setTimestamp();
}

export function buildSupportButtons() {
  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("tyt_ticket_general")
      .setLabel("General Support")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("tyt_ticket_player_report")
      .setLabel("Player Reporting")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("tyt_ticket_staff_report")
      .setLabel("Staff Reporting")
      .setStyle(ButtonStyle.Danger),
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("tyt_ticket_apply_staff")
      .setLabel("Applying for Staff")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId("tyt_ticket_apply_tester")
      .setLabel("Applying for Tester")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId("tyt_ticket_apply_hightest")
      .setLabel("Apply for High Test")
      .setStyle(ButtonStyle.Secondary),
  );

  return [row1, row2];
}

export function buildTicketEmbed(category: string, userTag: string) {
  const descriptions: Record<string, string> = {
    general:          "Welcome! Please describe your issue and a staff member will assist you shortly.",
    player_report:    "Please provide the player's username, evidence (screenshots/video), and a description of the incident.",
    staff_report:     "Please provide the staff member's username, evidence, and a detailed description of the incident.",
    apply_staff:      "Please tell us about yourself, your experience, and why you'd like to join the TYT Staff team.",
    apply_tester:     "Please tell us about yourself, your experience with Minecraft PvP, and why you'd like to become a TYT Tester.",
    apply_hightest:   "Please provide your current tier, evidence of your skill level, and why you believe you're ready for a High Test.",
  };

  const categoryLabels: Record<string, string> = {
    general:        "General Support",
    player_report:  "Player Report",
    staff_report:   "Staff Report",
    apply_staff:    "Staff Application",
    apply_tester:   "Tester Application",
    apply_hightest: "High Test Application",
  };

  return new EmbedBuilder()
    .setColor(COLORS.TICKET)
    .setTitle(`🎫 ${categoryLabels[category] ?? category}`)
    .setDescription(descriptions[category] ?? "Please describe your request.")
    .addFields({ name: "Opened by", value: `<@${userTag}>`, inline: true })
    .setFooter({ text: TYT_FOOTER })
    .setTimestamp();
}

export function buildTicketControlButtons(channelId: string) {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`tyt_ticket_claim_${channelId}`)
      .setLabel("Claim")
      .setStyle(ButtonStyle.Primary)
      .setEmoji("🙋"),
    new ButtonBuilder()
      .setCustomId(`tyt_ticket_close_${channelId}`)
      .setLabel("Close")
      .setStyle(ButtonStyle.Danger)
      .setEmoji("🔒"),
    new ButtonBuilder()
      .setCustomId(`tyt_ticket_transcript_${channelId}`)
      .setLabel("Transcript")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("📄"),
  );
}
