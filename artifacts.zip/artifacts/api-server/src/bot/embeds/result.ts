import { EmbedBuilder } from "discord.js";
import { getTierColor, getTierDisplayName } from "../utils/tiers.js";
import { TYT_FOOTER } from "./colors.js";

export function buildResultEmbed(opts: {
  playerTag: string;
  playerIgn: string;
  testerTag: string;
  gamemode: string;
  score: string;
  previousTier: string;
  newTier: string;
  notes?: string;
  skinUrl?: string;
  accountType?: string;
}) {
  const avatarUrl =
    opts.accountType === "cracked" && opts.skinUrl
      ? opts.skinUrl
      : `https://mc-heads.net/avatar/${encodeURIComponent(opts.playerIgn)}/128`;

  const embed = new EmbedBuilder()
    .setColor(getTierColor(opts.newTier))
    .setTitle(`🏆 ${opts.playerIgn}'s Tier Update`)
    .addFields(
      { name: "👤 Tester",            value: `<@${opts.testerTag}>`,              inline: true },
      { name: "🎮 Game Mode",          value: opts.gamemode,                        inline: true },
      { name: "\u200b",               value: "\u200b",                             inline: true },
      { name: "📊 Minecraft Username", value: opts.playerIgn,                       inline: true },
      { name: "⬇️ Previous Rank",      value: getTierDisplayName(opts.previousTier), inline: true },
      { name: "🏅 Rank Earned",        value: getTierDisplayName(opts.newTier),      inline: true },
      { name: "📈 Score",              value: opts.score,                           inline: false },
    )
    .setThumbnail(avatarUrl)
    .setFooter({ text: TYT_FOOTER })
    .setTimestamp();

  if (opts.notes) {
    embed.addFields({ name: "📝 Notes", value: opts.notes, inline: false });
  }

  return embed;
}

export function buildHighResultEmbed(opts: {
  playerTag: string;
  playerIgn: string;
  testerTag: string;
  tier: string;
  score: string;
  passed: boolean;
}) {
  const embed = new EmbedBuilder()
    .setColor(opts.passed ? 0x57f287 : 0xed4245)
    .setDescription(
      `<@${opts.playerTag}> — **${opts.playerIgn}** ${opts.passed ? `Passed` : `Failed`} ${getTierDisplayName(opts.tier)} ${opts.passed ? "✅" : "❌"}\n\n` +
      `**${opts.tier} Fights:**\n${opts.score}`,
    )
    .setFooter({ text: TYT_FOOTER })
    .setTimestamp();
  return embed;
}
