import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } from "discord.js";
import { COLORS, TYT_FOOTER } from "./colors.js";

export function buildRegistrationEmbed() {
  return new EmbedBuilder()
    .setColor(COLORS.TYT)
    .setTitle("📋 TestYourTier Testing Waitlist & Roles")
    .setDescription(
      "**Step 1: Register Your Profile**\nClick the **Register / Update Profile** button to save your IGN and account type.\n\n" +
      "**Step 2: Get a Waitlist Role**\nAfter registering, use the dropdown to select a gamemode and receive its waitlist role (**5-day cooldown** per gamemode).\n\n" +
      "• **Username:** the account you will be testing on\n" +
      "• **Account Type:** Premium or Cracked\n\n" +
      "👾 **Skin URL (Cracked Only)**\n" +
      "• Mineskin.org → upload skin → Generate\n" +
      "• Copy Image Address from the preview\n" +
      "• Paste that URL in the register form\n\n" +
      "⚠️ Failure to provide authentic information may result in a denied test.",
    )
    .setFooter({ text: TYT_FOOTER })
    .setTimestamp();
}

export function buildRegisterButton() {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("tyt_register_profile")
      .setLabel("Register / Update Profile")
      .setStyle(ButtonStyle.Success)
      .setEmoji("📝"),
  );
}

export function buildWaitlistSelect() {
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("tyt_waitlist_select")
      .setPlaceholder("Select a gamemode to get the waitlist role")
      .addOptions([
        { label: "Axe & Shield", value: "Axe & Shield", emoji: "🪓" },
        { label: "Neth Pot",     value: "Neth Pot",     emoji: "🧪" },
        { label: "Dia Pot",      value: "Dia Pot",      emoji: "💎" },
        { label: "SMP Kit",      value: "SMP Kit",      emoji: "🌿" },
        { label: "Mace",         value: "Mace",         emoji: "🔨" },
        { label: "Sword",        value: "Sword",        emoji: "⚔️" },
        { label: "UHC",          value: "UHC",          emoji: "🌍" },
        { label: "CPvP",         value: "CPvP",         emoji: "💥" },
      ]),
  );
}

export function buildAccountTypeSelect() {
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("tyt_account_type")
      .setPlaceholder("Select your account type")
      .addOptions([
        { label: "Premium (Official Minecraft)", value: "premium", emoji: "🖥️" },
        { label: "Cracked",                      value: "cracked", emoji: "🔒" },
      ]),
  );
}
