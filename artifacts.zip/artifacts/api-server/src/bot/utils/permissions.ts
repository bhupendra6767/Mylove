import { GuildMember, PermissionFlagsBits } from "discord.js";

export const STAFF_ROLES = ["TYT Admin", "TYT Staff"];
export const TESTER_ROLES = ["TYT Tester", "TYT High Tester", "TYT Admin", "TYT Staff"];
export const HIGH_TESTER_ROLES = ["TYT High Tester", "TYT Admin"];
export const ADMIN_ROLES = ["TYT Admin"];

export function hasRole(member: GuildMember, roleNames: string[]): boolean {
  return member.roles.cache.some((r) => roleNames.includes(r.name));
}

export function isStaff(member: GuildMember): boolean {
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  return hasRole(member, STAFF_ROLES);
}

export function isTester(member: GuildMember): boolean {
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  return hasRole(member, TESTER_ROLES);
}

export function isHighTester(member: GuildMember): boolean {
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  return hasRole(member, HIGH_TESTER_ROLES);
}

export function isAdmin(member: GuildMember): boolean {
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  return hasRole(member, ADMIN_ROLES);
}
