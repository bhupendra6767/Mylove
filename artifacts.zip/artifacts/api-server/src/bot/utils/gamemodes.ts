export const GAMEMODES = [
  "Axe & Shield",
  "Neth Pot",
  "Dia Pot",
  "SMP Kit",
  "Mace",
  "Sword",
  "UHC",
  "CPvP",
] as const;

export type Gamemode = (typeof GAMEMODES)[number];

export const GAMEMODE_EMOJIS: Record<Gamemode, string> = {
  "Axe & Shield": "🪓",
  "Neth Pot":     "🧪",
  "Dia Pot":      "💎",
  "SMP Kit":      "🌿",
  "Mace":         "🔨",
  "Sword":        "⚔️",
  "UHC":          "🌍",
  "CPvP":         "💥",
};

export const GAMEMODE_CHANNEL_NAMES: Record<Gamemode, string> = {
  "Axe & Shield": "axe-queue",
  "Neth Pot":     "nethpot-queue",
  "Dia Pot":      "diapot-queue",
  "SMP Kit":      "smp-queue",
  "Mace":         "mace-queue",
  "Sword":        "sword-queue",
  "UHC":          "uhc-queue",
  "CPvP":         "cpvp-queue",
};

export const GAMEMODE_WAITLIST_ROLES: Record<Gamemode, string> = {
  "Axe & Shield": "Waitlist [Axe & Shield]",
  "Neth Pot":     "Waitlist [Neth Pot]",
  "Dia Pot":      "Waitlist [Dia Pot]",
  "SMP Kit":      "Waitlist [SMP Kit]",
  "Mace":         "Waitlist [Mace]",
  "Sword":        "Waitlist [Sword]",
  "UHC":          "Waitlist [UHC]",
  "CPvP":         "Waitlist [CPvP]",
};

export function isGamemode(value: string): value is Gamemode {
  return GAMEMODES.includes(value as Gamemode);
}

export const GAMEMODE_COLORS: Record<Gamemode, number> = {
  "Axe & Shield": 0xe67e22,
  "Neth Pot":     0xe74c3c,
  "Dia Pot":      0x3498db,
  "SMP Kit":      0x2ecc71,
  "Mace":         0x9b59b6,
  "Sword":        0x1abc9c,
  "UHC":          0xf39c12,
  "CPvP":         0xe91e63,
};
