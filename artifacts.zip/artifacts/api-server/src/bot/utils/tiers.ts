export const TIERS = [
  "HT1", "HT2", "HT3", "HT4", "HT5",
  "MT1", "MT2", "MT3", "MT4", "MT5",
  "LT1", "LT2", "LT3", "LT4", "LT5",
  "Unranked",
] as const;

export type Tier = (typeof TIERS)[number];

export const TIER_DISPLAY: Record<string, string> = {
  HT1: "High Tier 1", HT2: "High Tier 2", HT3: "High Tier 3", HT4: "High Tier 4", HT5: "High Tier 5",
  MT1: "Mid Tier 1",  MT2: "Mid Tier 2",  MT3: "Mid Tier 3",  MT4: "Mid Tier 4",  MT5: "Mid Tier 5",
  LT1: "Low Tier 1",  LT2: "Low Tier 2",  LT3: "Low Tier 3",  LT4: "Low Tier 4",  LT5: "Low Tier 5",
  Unranked: "Unranked",
};

export const TIER_POINTS: Record<string, number> = {
  HT1: 16, HT2: 15, HT3: 14, HT4: 13, HT5: 12,
  MT1: 11, MT2: 10, MT3: 9,  MT4: 8,  MT5: 7,
  LT1: 6,  LT2: 5,  LT3: 4,  LT4: 3,  LT5: 2,
  Unranked: 0,
};

export const TIER_COLORS: Record<string, number> = {
  HT1: 0xff0000, HT2: 0xff0000, HT3: 0xff0000, HT4: 0xff0000, HT5: 0xff0000,
  MT1: 0xff8800, MT2: 0xff8800, MT3: 0xff8800, MT4: 0xff8800, MT5: 0xff8800,
  LT1: 0x00cc44, LT2: 0x00cc44, LT3: 0x00cc44, LT4: 0x00cc44, LT5: 0x00cc44,
  Unranked: 0x888888,
};

export function getTierColor(tier: string): number {
  return TIER_COLORS[tier] ?? 0x5865f2;
}

export function getTierDisplayName(tier: string): string {
  return TIER_DISPLAY[tier] ?? tier;
}

export function isTier(value: string): value is Tier {
  return TIERS.includes(value as Tier);
}
