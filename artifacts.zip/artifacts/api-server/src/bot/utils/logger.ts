import { Guild, TextChannel } from "discord.js";
import { db } from "@workspace/db";
import { logsTable } from "@workspace/db";

export async function logAction(
  guild: Guild,
  action: string,
  userId?: string,
  details?: string,
): Promise<void> {
  try {
    await db.insert(logsTable).values({
      guildId: guild.id,
      action,
      userId,
      details,
    });

    const logChannel = guild.channels.cache.find(
      (c) => c.name === "tyt-logs" && c.isTextBased(),
    ) as TextChannel | undefined;

    if (logChannel) {
      const timestamp = `<t:${Math.floor(Date.now() / 1000)}:R>`;
      const userMention = userId ? `<@${userId}>` : "System";
      await logChannel
        .send(`📋 **${action}** | ${userMention} ${timestamp}${details ? `\n> ${details}` : ""}`)
        .catch(() => null);
    }
  } catch {
    // silently fail — logs are non-critical
  }
}
