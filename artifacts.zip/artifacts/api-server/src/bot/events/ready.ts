import { type Client, ActivityType } from "discord.js";
import { logger } from "../../lib/logger.js";

export async function handleReady(client: Client) {
  if (!client.user) return;

  client.user.setPresence({
    activities: [{ name: "TestYourTier | /profile", type: ActivityType.Watching }],
    status: "online",
  });

  logger.info(`✅ TestYourTier bot online as ${client.user.tag}`);
  logger.info(`📊 Serving ${client.guilds.cache.size} guild(s)`);
}
