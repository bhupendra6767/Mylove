import { type Interaction, type Client } from "discord.js";
import { logger } from "../../lib/logger.js";
import type { BotCommand } from "../client.js";

// Button handlers
import { handleRegisterProfile } from "../buttons/register.js";
import { handleQueueJoin, handleQueueLeave, handleQueueNext, handleQueueClose } from "../buttons/queue.js";
import {
  handleOpenTicket,
  handleClaimTicket,
  handleCloseTicket,
  handleTranscriptTicket,
} from "../buttons/ticket.js";
import { handleLeaderboardNav } from "../buttons/leaderboard.js";

// Select menu handlers
import { handleAccountTypeSelect } from "../selectmenus/account-type.js";
import { handleWaitlistSelect } from "../selectmenus/waitlist.js";
import { handleLeaderboardGamemodeSelect } from "../selectmenus/leaderboard.js";
import { handleAutoSetupChannelSelect, handleAutoSetupSkip } from "../selectmenus/autosetup.js";

// Modal handlers
import { handleProfileModal } from "../modals/profile.js";
import { handleQueueCloseModal } from "../modals/queue-close.js";

// Help command pages
import { PAGES, buildHelpComponents } from "../commands/help.js";

import type { Collection } from "discord.js";

export async function handleInteractionCreate(interaction: Interaction, client: Client) {
  try {
    // ── Slash Commands ──────────────────────────────────────────────────────
    if (interaction.isChatInputCommand()) {
      const commands = (client as unknown as { commands: Collection<string, BotCommand> }).commands;
      const command = commands.get(interaction.commandName);
      if (!command) {
        logger.warn({ cmd: interaction.commandName }, "Unknown command");
        return;
      }
      await command.execute(interaction);
      return;
    }

    // ── Buttons ─────────────────────────────────────────────────────────────
    if (interaction.isButton()) {
      const id = interaction.customId;

      // Register / Update Profile
      if (id === "tyt_register_profile") {
        await handleRegisterProfile(interaction);
        return;
      }

      // Queue buttons: tyt_queue_{action}_{safeGamemode}
      const queueMatch = id.match(/^tyt_queue_(join|leave|next|close)_(.+)$/);
      if (queueMatch) {
        const [, action, safeGm] = queueMatch;
        if (action === "join")  { await handleQueueJoin(interaction, safeGm!);  return; }
        if (action === "leave") { await handleQueueLeave(interaction, safeGm!); return; }
        if (action === "next")  { await handleQueueNext(interaction, safeGm!);  return; }
        if (action === "close") { await handleQueueClose(interaction, safeGm!); return; }
      }

      // Ticket open buttons
      if (id.startsWith("tyt_ticket_") && !id.includes("_claim_") && !id.includes("_close_") && !id.includes("_transcript_")) {
        await handleOpenTicket(interaction);
        return;
      }

      // Ticket control: tyt_ticket_{action}_{channelId}
      const ticketCtrlMatch = id.match(/^tyt_ticket_(claim|close|transcript)_(.+)$/);
      if (ticketCtrlMatch) {
        const [, action, channelId] = ticketCtrlMatch;
        if (action === "claim")      { await handleClaimTicket(interaction, channelId!);      return; }
        if (action === "close")      { await handleCloseTicket(interaction, channelId!);      return; }
        if (action === "transcript") { await handleTranscriptTicket(interaction, channelId!); return; }
      }

      // Leaderboard navigation: tyt_lb_{prev|next}_{type}_{page}_{safeGm}
      const lbMatch = id.match(/^tyt_lb_(prev|next)_(points|wins|winstreak|activity)_(\d+)_(.+)$/);
      if (lbMatch) {
        const [, dir, type, pageStr, safeGm] = lbMatch;
        await handleLeaderboardNav(
          interaction,
          dir as "prev" | "next",
          type as "points" | "wins" | "winstreak" | "activity",
          parseInt(pageStr!, 10),
          safeGm!,
        );
        return;
      }

      // Help navigation: tyt_help_{prev|next}_{page}
      const helpMatch = id.match(/^tyt_help_(prev|next)_(\d+)$/);
      if (helpMatch) {
        const [, dir, pageStr] = helpMatch;
        const currentPage = parseInt(pageStr!, 10);
        const newPage = dir === "prev" ? currentPage - 1 : currentPage + 1;
        const clampedPage = Math.max(0, Math.min(PAGES.length - 1, newPage));
        await interaction.update({
          embeds: [PAGES[clampedPage]!.embed()],
          components: buildHelpComponents(clampedPage),
        });
        return;
      }

      // AutoSetup skip buttons: tyt_autosetup_skip_{step}
      const autoSetupSkipMatch = id.match(/^tyt_autosetup_skip_(reg|support)$/);
      if (autoSetupSkipMatch) {
        await handleAutoSetupSkip(interaction, autoSetupSkipMatch[1]! as "reg" | "support");
        return;
      }

      // Ignore disabled buttons
      if (id.startsWith("disabled_")) return;

      logger.warn({ id }, "Unhandled button");
      return;
    }

    // ── String Select Menus ───────────────────────────────────────────────────
    if (interaction.isStringSelectMenu()) {
      const id = interaction.customId;

      if (id === "tyt_account_type") {
        await handleAccountTypeSelect(interaction);
        return;
      }

      if (id === "tyt_waitlist_select") {
        await handleWaitlistSelect(interaction);
        return;
      }

      // Leaderboard gamemode: tyt_lb_gamemode_{type}_{page}
      const lbGmMatch = id.match(/^tyt_lb_gamemode_(points|wins|winstreak|activity)_(\d+)$/);
      if (lbGmMatch) {
        const [, type, pageStr] = lbGmMatch;
        await handleLeaderboardGamemodeSelect(
          interaction,
          type as "points" | "wins" | "winstreak" | "activity",
          parseInt(pageStr!, 10),
        );
        return;
      }

      logger.warn({ id }, "Unhandled string select menu");
      return;
    }

    // ── Channel Select Menus ──────────────────────────────────────────────────
    if (interaction.isChannelSelectMenu()) {
      const id = interaction.customId;

      if (id === "tyt_autosetup_reg") {
        await handleAutoSetupChannelSelect(interaction, "reg");
        return;
      }

      if (id === "tyt_autosetup_support") {
        await handleAutoSetupChannelSelect(interaction, "support");
        return;
      }

      logger.warn({ id }, "Unhandled channel select menu");
      return;
    }

    // ── Modals ───────────────────────────────────────────────────────────────
    if (interaction.isModalSubmit()) {
      const id = interaction.customId;

      // Profile modal: tyt_profile_modal_{accountType}
      const profileMatch = id.match(/^tyt_profile_modal_(premium|cracked)$/);
      if (profileMatch) {
        await handleProfileModal(interaction, profileMatch[1]!);
        return;
      }

      // Queue close modal: tyt_queue_close_modal_{safeGm}
      const queueCloseMatch = id.match(/^tyt_queue_close_modal_(.+)$/);
      if (queueCloseMatch) {
        await handleQueueCloseModal(interaction, queueCloseMatch[1]!);
        return;
      }

      logger.warn({ id }, "Unhandled modal");
      return;
    }
  } catch (err) {
    logger.error({ err }, "Error handling interaction");

    const errorMessage = "❌ An error occurred processing your request. Please try again.";
    try {
      if (interaction.isRepliable()) {
        if ("replied" in interaction && interaction.replied) {
          await (interaction as import("discord.js").ChatInputCommandInteraction).followUp({
            content: errorMessage,
            ephemeral: true,
          });
        } else if ("deferred" in interaction && interaction.deferred) {
          await (interaction as import("discord.js").ChatInputCommandInteraction).editReply({
            content: errorMessage,
          });
        } else {
          await (interaction as import("discord.js").ChatInputCommandInteraction).reply({
            content: errorMessage,
            ephemeral: true,
          });
        }
      }
    } catch {
      // Can't send error — ignore
    }
  }
}
