import { type ModalSubmitInteraction, EmbedBuilder } from "discord.js";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { COLORS } from "../embeds/colors.js";
import { buildWaitlistSelect } from "../embeds/registration.js";
import { logAction } from "../utils/logger.js";

export async function handleProfileModal(interaction: ModalSubmitInteraction, accountType: string) {
  const ign = interaction.fields.getTextInputValue("ign").trim();
  const skinUrl = interaction.fields.getTextInputValue("skin_url")?.trim() || null;

  if (!ign) {
    await interaction.reply({ content: "❌ IGN is required.", ephemeral: true });
    return;
  }

  if (accountType === "cracked" && !skinUrl) {
    await interaction.reply({
      content:
        "❌ Cracked players must provide a skin URL.\n\n" +
        "**How to get your skin URL:**\n" +
        "1. Go to [Mineskin.org](https://mineskin.org)\n" +
        "2. Upload your skin `.png`, click GENERATE\n" +
        "3. Right-click the skin preview → Copy Image Address\n" +
        "4. Paste that URL in the form",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const existing = await db.query.usersTable.findFirst({
    where: eq(usersTable.discordId, interaction.user.id),
  });

  if (existing) {
    await db
      .update(usersTable)
      .set({
        username: interaction.user.username,
        ign,
        accountType,
        skinUrl: skinUrl ?? existing.skinUrl,
        updatedAt: new Date(),
      })
      .where(eq(usersTable.discordId, interaction.user.id));
  } else {
    await db.insert(usersTable).values({
      discordId: interaction.user.id,
      username: interaction.user.username,
      ign,
      accountType,
      skinUrl,
      currentTier: "Unranked",
    });

    // Assign Unranked role if it exists
    if (interaction.guild) {
      const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
      const unrankedRole = interaction.guild.roles.cache.find((r) => r.name === "Unranked");
      if (member && unrankedRole) {
        await member.roles.add(unrankedRole).catch(() => null);
      }
    }
  }

  const embed = new EmbedBuilder()
    .setColor(COLORS.SUCCESS)
    .setTitle("✅ Profile saved")
    .addFields(
      { name: "🧑 Username", value: ign,      inline: true },
      { name: "🖥️ Account Type", value: accountType === "premium" ? "Premium" : "Cracked", inline: true },
      { name: "🪪 UUID",          value: "N/A", inline: true },
    )
    .setFooter({ text: `TestYourTier | ${new Date().toLocaleDateString()}` });

  const waitlistSelect = buildWaitlistSelect();

  if (interaction.guild) {
    await logAction(
      interaction.guild,
      existing ? "Profile Updated" : "Profile Created",
      interaction.user.id,
      `IGN: ${ign} | Type: ${accountType}`,
    );
  }

  await interaction.editReply({ embeds: [embed], components: [waitlistSelect] });
}
