import { type ModalSubmitInteraction, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import { db } from "@workspace/db";
import { queueSessionsTable, queueEntriesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { buildQueueEmbed } from "../embeds/queue.js";
import { type Gamemode } from "../utils/gamemodes.js";
import { logAction } from "../utils/logger.js";

function getGamemode(safeGm: string): string {
  const map: Record<string, string> = {
    "Axe___Shield": "Axe & Shield",
    "Axe_&_Shield": "Axe & Shield",
    "Neth_Pot": "Neth Pot",
    "Dia_Pot": "Dia Pot",
    "SMP_Kit": "SMP Kit",
    "Mace": "Mace",
    "Sword": "Sword",
    "UHC": "UHC",
    "CPvP": "CPvP",
  };
  return map[safeGm] ?? safeGm.replace(/_/g, " ");
}

export async function handleQueueCloseModal(interaction: ModalSubmitInteraction, safeGm: string) {
  const reason = interaction.fields.getTextInputValue("reason").trim();
  const gamemode = getGamemode(safeGm);

  await interaction.deferReply({ ephemeral: true });

  const session = await db.query.queueSessionsTable.findFirst({
    where: and(
      eq(queueSessionsTable.gamemode, gamemode),
      eq(queueSessionsTable.status, "open"),
    ),
  });

  if (!session) {
    await interaction.editReply({ content: "❌ No active queue session found." });
    return;
  }

  // Close the session
  await db
    .update(queueSessionsTable)
    .set({
      status: "closed",
      closedAt: new Date(),
      closeReason: reason,
    })
    .where(eq(queueSessionsTable.id, session.id));

  // Clear all queue entries
  await db.delete(queueEntriesTable).where(eq(queueEntriesTable.sessionId, session.id));

  // Update the queue message to show closed state
  if (session.messageId && interaction.channel) {
    try {
      const embed = buildQueueEmbed(
        gamemode as Gamemode,
        [],
        session.testerId,
        false,
        new Date(session.openedAt),
      );

      const closedRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("disabled_join").setLabel("Join").setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId("disabled_leave").setLabel("Leave").setStyle(ButtonStyle.Secondary).setDisabled(true),
        new ButtonBuilder().setCustomId("disabled_next").setLabel("Next").setStyle(ButtonStyle.Primary).setDisabled(true),
        new ButtonBuilder().setCustomId("disabled_close").setLabel("Close").setStyle(ButtonStyle.Danger).setDisabled(true),
      );

      const msg = await interaction.channel.messages.fetch(session.messageId).catch(() => null);
      if (msg) {
        await msg.edit({
          embeds: [embed],
          components: [closedRow],
        });
      }
    } catch {
      // best effort
    }
  }

  if (interaction.guild) {
    await logAction(
      interaction.guild,
      "Queue Closed",
      interaction.user.id,
      `${gamemode} — Reason: ${reason}`,
    );
  }

  await interaction.editReply({
    content: `✅ **${gamemode}** queue has been closed.\n📋 **Reason:** ${reason}`,
  });
}
