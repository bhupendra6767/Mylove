import { REST, Routes } from "discord.js";
import { logger } from "../lib/logger.js";
import * as commands from "./commands/index.js";

export async function deployCommands(clientId: string, guildId?: string) {
  const token = process.env["DISCORD_TOKEN"];
  if (!token) throw new Error("DISCORD_TOKEN is required");

  const rest = new REST().setToken(token);

  const commandData = Object.values(commands).map((cmd) => cmd.data.toJSON());

  try {
    if (guildId) {
      // Guild commands deploy instantly (for dev)
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
        body: commandData,
      });
      logger.info({ count: commandData.length, guildId }, "Deployed guild slash commands");
    } else {
      // Global commands (up to 1hr to propagate)
      await rest.put(Routes.applicationCommands(clientId), {
        body: commandData,
      });
      logger.info({ count: commandData.length }, "Deployed global slash commands");
    }
  } catch (err) {
    logger.error({ err }, "Failed to deploy slash commands");
    throw err;
  }
}
