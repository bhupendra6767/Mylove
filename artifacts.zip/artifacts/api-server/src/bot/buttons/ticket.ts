import {
  type ButtonInteraction,
  ChannelType,
  PermissionFlagsBits,
  TextChannel,
  EmbedBuilder,
} from "discord.js";
import { db } from "@workspace/db";
import { ticketsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { buildTicketEmbed, buildTicketControlButtons } from "../embeds/ticket.js";
import { isStaff } from "../utils/permissions.js";
import { COLORS } from "../embeds/colors.js";
import { logAction } from "../utils/logger.js";

const TICKET_CATEGORIES: Record<string, string> = {
  tyt_ticket_general:          "general",
  tyt_ticket_player_report:    "player_report",
  tyt_ticket_staff_report:     "staff_report",
  tyt_ticket_apply_staff:      "apply_staff",
  tyt_ticket_apply_tester:     "apply_tester",
  tyt_ticket_apply_hightest:   "apply_hightest",
};

const CATEGORY_LABELS: Record<string, string> = {
  general:          "General Support",
  player_report:    "Player Report",
  staff_report:     "Staff Report",
  apply_staff:      "Staff Application",
  apply_tester:     "Tester Application",
  apply_hightest:   "High Test Application",
};

export async function handleOpenTicket(interaction: ButtonInteraction) {
  if (!interaction.guild) return;

  const category = TICKET_CATEGORIES[interaction.customId];
  if (!category) return;

  await interaction.deferReply({ ephemeral: true });

  // Check for existing open ticket
  const existing = await db.query.ticketsTable.findFirst({
    where: eq(ticketsTable.userId, interaction.user.id),
  });

  if (existing && existing.status === "open") {
    const existingCh = interaction.guild.channels.cache.get(existing.channelId);
    if (existingCh) {
      await interaction.editReply({
        content: `❌ You already have an open ticket: ${existingCh}`,
      });
      return;
    }
  }

  // Find or create support category
  let parentCategory = interaction.guild.channels.cache.find(
    (c) => c.name.toLowerCase().includes("support") && c.type === ChannelType.GuildCategory,
  );

  // Get staff role for permissions
  const staffRole = interaction.guild.roles.cache.find((r) => r.name === "TYT Staff");
  const adminRole = interaction.guild.roles.cache.find((r) => r.name === "TYT Admin");

  const channelName = `ticket-${interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, "")}`;

  const ticketChannel = await interaction.guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: parentCategory?.id,
    permissionOverwrites: [
      {
        id: interaction.guild.roles.everyone.id,
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: interaction.user.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      },
      ...(staffRole ? [{
        id: staffRole.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages],
      }] : []),
      ...(adminRole ? [{
        id: adminRole.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages],
      }] : []),
    ],
  }) as TextChannel;

  await db.insert(ticketsTable).values({
    userId: interaction.user.id,
    category,
    channelId: ticketChannel.id,
    status: "open",
  });

  const embed = buildTicketEmbed(category, interaction.user.id);
  const controls = buildTicketControlButtons(ticketChannel.id);

  await ticketChannel.send({
    content: `<@${interaction.user.id}>${staffRole ? ` | ${staffRole}` : ""}`,
    embeds: [embed],
    components: [controls],
  });

  await logAction(
    interaction.guild,
    "Ticket Opened",
    interaction.user.id,
    `${CATEGORY_LABELS[category] ?? category} — #${channelName}`,
  );

  await interaction.editReply({
    content: `✅ Your ticket has been created: ${ticketChannel}`,
  });
}

export async function handleClaimTicket(interaction: ButtonInteraction, channelId: string) {
  if (!interaction.guild) return;

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!isStaff(member)) {
    await interaction.reply({ content: "❌ Only staff can claim tickets.", ephemeral: true });
    return;
  }

  const ticket = await db.query.ticketsTable.findFirst({
    where: eq(ticketsTable.channelId, channelId),
  });

  if (!ticket) {
    await interaction.reply({ content: "❌ Ticket not found.", ephemeral: true });
    return;
  }

  await db.update(ticketsTable).set({ claimedBy: interaction.user.id }).where(eq(ticketsTable.channelId, channelId));

  await interaction.reply({
    content: `🙋 This ticket has been claimed by <@${interaction.user.id}>`,
  });
}

export async function handleCloseTicket(interaction: ButtonInteraction, channelId: string) {
  if (!interaction.guild) return;

  const member = await interaction.guild.members.fetch(interaction.user.id);

  const ticket = await db.query.ticketsTable.findFirst({
    where: eq(ticketsTable.channelId, channelId),
  });

  if (!ticket) {
    await interaction.reply({ content: "❌ Ticket not found.", ephemeral: true });
    return;
  }

  const isOwner = ticket.userId === interaction.user.id;
  if (!isOwner && !isStaff(member)) {
    await interaction.reply({ content: "❌ You don't have permission to close this ticket.", ephemeral: true });
    return;
  }

  await db
    .update(ticketsTable)
    .set({ status: "closed", closedAt: new Date() })
    .where(eq(ticketsTable.channelId, channelId));

  const channel = interaction.guild.channels.cache.get(channelId) as TextChannel | undefined;

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.ERROR)
        .setTitle("🔒 Ticket Closed")
        .setDescription(`Ticket closed by <@${interaction.user.id}>.\nThis channel will be deleted in 5 seconds.`)
        .setTimestamp(),
    ],
  });

  await logAction(interaction.guild, "Ticket Closed", interaction.user.id, `#${channel?.name ?? channelId}`);

  setTimeout(async () => {
    await channel?.delete("Ticket closed").catch(() => null);
  }, 5000);
}

export async function handleTranscriptTicket(interaction: ButtonInteraction, channelId: string) {
  if (!interaction.guild) return;

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!isStaff(member)) {
    await interaction.reply({ content: "❌ Only staff can generate transcripts.", ephemeral: true });
    return;
  }

  const channel = interaction.guild.channels.cache.get(channelId) as TextChannel | undefined;
  if (!channel) {
    await interaction.reply({ content: "❌ Channel not found.", ephemeral: true });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const messages = await channel.messages.fetch({ limit: 100 });
  const transcript = messages
    .reverse()
    .map((m) => `[${m.createdAt.toISOString()}] ${m.author.tag}: ${m.content}`)
    .join("\n");

  const buffer = Buffer.from(transcript, "utf-8");

  await interaction.editReply({
    content: "📄 Here is the transcript:",
    files: [{ attachment: buffer, name: `transcript-${channel.name}.txt` }],
  });
}
