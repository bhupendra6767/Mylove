import {
  type ButtonInteraction,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
} from "discord.js";
import { db } from "@workspace/db";
import { queueSessionsTable, queueEntriesTable, usersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { buildQueueEmbed, buildQueueButtons } from "../embeds/queue.js";
import { isTester } from "../utils/permissions.js";
import { type Gamemode } from "../utils/gamemodes.js";
import { logAction } from "../utils/logger.js";

function getGamemode(safeGm: string): string {
  // Convert safe (underscored) gamemode back
  const map: Record<string, string> = {
    "Axe___Shield": "Axe & Shield",
    "Axe_&_Shield": "Axe & Shield",
    "Neth_Pot": "Neth Pot",
    "Dia_Pot": "Dia Pot",
    "SMP_Kit": "SMP Kit",
    "Mace": "Mace",
    "Sword": "Sword",
    "UHC": "UHC",
    "CPvP": "CPvP",
  };
  return map[safeGm] ?? safeGm.replace(/_/g, " ");
}

async function getQueueData(gamemode: string) {
  const session = await db.query.queueSessionsTable.findFirst({
    where: and(
      eq(queueSessionsTable.gamemode, gamemode),
      eq(queueSessionsTable.status, "open"),
    ),
  });
  if (!session) return null;

  const entries = await db.query.queueEntriesTable.findMany({
    where: eq(queueEntriesTable.sessionId, session.id),
  });
  return { session, entries };
}

async function refreshQueueMessage(interaction: ButtonInteraction, gamemode: string) {
  const data = await getQueueData(gamemode);
  if (!data || !data.session.messageId) return;

  const { session, entries } = data;
  const queueEntries = entries.map((e) => ({
    userId: e.userId,
    username: e.userId,
    position: e.position,
  }));

  const embed = buildQueueEmbed(
    gamemode as Gamemode,
    queueEntries,
    session.testerId,
    true,
    new Date(session.openedAt),
  );
  const buttons = buildQueueButtons(gamemode, true);

  try {
    const msg = session.messageId ? await interaction.channel?.messages.fetch(session.messageId) : null;
    if (msg) await msg.edit({ embeds: [embed], components: buttons });
  } catch {
    // message might have been deleted
  }
}

export async function handleQueueJoin(interaction: ButtonInteraction, safeGm: string) {
  const gamemode = getGamemode(safeGm);
  const data = await getQueueData(gamemode);

  if (!data) {
    await interaction.reply({ content: "❌ No active queue for this gamemode.", ephemeral: true });
    return;
  }

  const { session, entries } = data;

  // Check if queue-banned
  const userRecord = await db.query.usersTable.findFirst({
    where: eq(usersTable.discordId, interaction.user.id),
  });
  if (userRecord?.queueBanned) {
    await interaction.reply({
      content:
        `🔨 You are **banned from joining queues**.` +
        (userRecord.queueBannedReason ? `\n> **Reason:** ${userRecord.queueBannedReason}` : "") +
        `\nContact a staff member to appeal.`,
      ephemeral: true,
    });
    return;
  }

  // Check if already in queue
  if (entries.some((e) => e.userId === interaction.user.id)) {
    await interaction.reply({ content: "❌ You are already in the queue!", ephemeral: true });
    return;
  }

  const position = entries.length + 1;
  await db.insert(queueEntriesTable).values({
    sessionId: session.id,
    userId: interaction.user.id,
    gamemode,
    position,
  });

  await interaction.reply({
    content: `✅ You joined the **${gamemode}** queue at position **#${position}**!`,
    ephemeral: true,
  });

  await refreshQueueMessage(interaction, gamemode);
  if (interaction.guild) {
    await logAction(interaction.guild, "Queue Join", interaction.user.id, `${gamemode} — position #${position}`);
  }
}

export async function handleQueueLeave(interaction: ButtonInteraction, safeGm: string) {
  const gamemode = getGamemode(safeGm);
  const data = await getQueueData(gamemode);

  if (!data) {
    await interaction.reply({ content: "❌ No active queue for this gamemode.", ephemeral: true });
    return;
  }

  const { session, entries } = data;
  const entry = entries.find((e) => e.userId === interaction.user.id);

  if (!entry) {
    await interaction.reply({ content: "❌ You are not in this queue.", ephemeral: true });
    return;
  }

  await db
    .delete(queueEntriesTable)
    .where(eq(queueEntriesTable.id, entry.id));

  // Reorder remaining entries
  const remaining = entries
    .filter((e) => e.id !== entry.id)
    .sort((a, b) => a.position - b.position);

  for (let i = 0; i < remaining.length; i++) {
    await db
      .update(queueEntriesTable)
      .set({ position: i + 1 })
      .where(eq(queueEntriesTable.id, remaining[i]!.id));
  }

  await interaction.reply({ content: `✅ You have left the **${gamemode}** queue.`, ephemeral: true });
  await refreshQueueMessage(interaction, gamemode);

  if (interaction.guild) {
    await logAction(interaction.guild, "Queue Leave", interaction.user.id, gamemode);
  }
}

export async function handleQueueNext(interaction: ButtonInteraction, safeGm: string) {
  if (!interaction.guild) return;

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!isTester(member)) {
    await interaction.reply({ content: "❌ Only testers can call the next player.", ephemeral: true });
    return;
  }

  const gamemode = getGamemode(safeGm);
  const data = await getQueueData(gamemode);

  if (!data) {
    await interaction.reply({ content: "❌ No active queue for this gamemode.", ephemeral: true });
    return;
  }

  const { session, entries } = data;
  const nextEntry = entries.sort((a, b) => a.position - b.position)[0];

  if (!nextEntry) {
    await interaction.reply({ content: "❌ The queue is empty.", ephemeral: true });
    return;
  }

  // Remove from queue
  await db.delete(queueEntriesTable).where(eq(queueEntriesTable.id, nextEntry.id));

  // Reorder remaining
  const remaining = entries
    .filter((e) => e.id !== nextEntry.id)
    .sort((a, b) => a.position - b.position);
  for (let i = 0; i < remaining.length; i++) {
    await db
      .update(queueEntriesTable)
      .set({ position: i + 1 })
      .where(eq(queueEntriesTable.id, remaining[i]!.id));
  }

  // Create private thread for testing
  if (interaction.channel && "threads" in interaction.channel) {
    const ch = interaction.channel as import("discord.js").TextChannel;
    const targetMember = await interaction.guild.members.fetch(nextEntry.userId).catch(() => null);
    const threadName = `testing-${targetMember?.user.username ?? nextEntry.userId}`;

    try {
      const thread = await ch.threads.create({
        name: threadName,
        autoArchiveDuration: 60,
        reason: `Testing session for <@${nextEntry.userId}>`,
      });

      // Add tester and player to thread
      await thread.members.add(interaction.user.id);
      await thread.members.add(nextEntry.userId);

      // Add staff
      const staffRole = interaction.guild.roles.cache.find((r) => r.name === "TYT Staff");
      if (staffRole) {
        const staffMembers = staffRole.members;
        for (const [, sm] of staffMembers) {
          await thread.members.add(sm.id).catch(() => null);
        }
      }

      await thread.send(
        `🎮 **Testing Session Started**\n\n` +
        `👤 Player: <@${nextEntry.userId}>\n` +
        `🧑‍⚖️ Tester: <@${interaction.user.id}>\n` +
        `🎯 Gamemode: **${gamemode}**\n\n` +
        `Good luck! Use \`/result submit\` when done.`,
      );

      await interaction.reply({
        content: `✅ Called <@${nextEntry.userId}>! Thread: ${thread}`,
        ephemeral: false,
      });
    } catch {
      await interaction.reply({
        content: `✅ Called <@${nextEntry.userId}> for their **${gamemode}** test!`,
        ephemeral: false,
      });
    }
  } else {
    await interaction.reply({
      content: `✅ Called <@${nextEntry.userId}> for their **${gamemode}** test!`,
      ephemeral: false,
    });
  }

  await refreshQueueMessage(interaction, gamemode);
}

export async function handleQueueClose(interaction: ButtonInteraction, safeGm: string) {
  if (!interaction.guild) return;

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!isTester(member)) {
    await interaction.reply({ content: "❌ Only testers can close the queue.", ephemeral: true });
    return;
  }

  const gamemode = getGamemode(safeGm);

  // Show reason modal
  const modal = new ModalBuilder()
    .setCustomId(`tyt_queue_close_modal_${safeGm}`)
    .setTitle(`Close ${gamemode} Queue`);

  const reasonInput = new TextInputBuilder()
    .setCustomId("reason")
    .setLabel("Reason for closing the queue")
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder("e.g. Session ended for today")
    .setRequired(true)
    .setMaxLength(500);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(reasonInput));
  await interaction.showModal(modal);
}
