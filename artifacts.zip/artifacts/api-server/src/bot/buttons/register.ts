import { type ButtonInteraction } from "discord.js";
import { buildAccountTypeSelect } from "../embeds/registration.js";
import { EmbedBuilder } from "discord.js";
import { COLORS } from "../embeds/colors.js";

export async function handleRegisterProfile(interaction: ButtonInteraction) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.TYT)
    .setTitle("📋 Profile Registration — Step 1/2")
    .setDescription("👀 Select your **account type** below to continue.");

  const select = buildAccountTypeSelect();
  await interaction.reply({ embeds: [embed], components: [select], ephemeral: true });
}
