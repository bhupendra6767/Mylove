import { type ButtonInteraction } from "discord.js";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { buildLeaderboardEmbed, buildLeaderboardButtons, type LeaderboardType } from "../embeds/leaderboard.js";

function getGamemode(safe: string): string {
  const map: Record<string, string> = {
    "Axe___Shield": "Axe & Shield",
    "Axe_&_Shield": "Axe & Shield",
    "Neth_Pot": "Neth Pot",
    "Dia_Pot": "Dia Pot",
    "SMP_Kit": "SMP Kit",
    "Mace": "Mace",
    "Sword": "Sword",
    "UHC": "UHC",
    "CPvP": "CPvP",
    "Overall": "Overall",
  };
  return map[safe] ?? safe.replace(/_/g, " ");
}

export async function handleLeaderboardNav(
  interaction: ButtonInteraction,
  direction: "prev" | "next",
  type: LeaderboardType,
  page: number,
  safeGm: string,
) {
  await interaction.deferUpdate();

  const newPage = direction === "prev" ? Math.max(0, page - 1) : page + 1;
  const gamemode = getGamemode(safeGm);

  const orderCol =
    type === "points"    ? usersTable.points :
    type === "wins"      ? usersTable.wins :
    type === "winstreak" ? usersTable.winStreak :
                           usersTable.totalTests;

  let users;
  if (gamemode !== "Overall") {
    users = await db.select().from(usersTable).where(eq(usersTable.currentGamemode, gamemode)).orderBy(desc(orderCol));
  } else {
    users = await db.select().from(usersTable).orderBy(desc(orderCol));
  }

  const embed = buildLeaderboardEmbed(users, type, newPage, gamemode);
  const components = buildLeaderboardButtons(type, newPage, gamemode, users.length);

  await interaction.editReply({ embeds: [embed], components });
}
