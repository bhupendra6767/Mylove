import { type StringSelectMenuInteraction, EmbedBuilder } from "discord.js";
import { db } from "@workspace/db";
import { usersTable, waitlistRolesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { COLORS } from "../embeds/colors.js";
import { GAMEMODE_WAITLIST_ROLES, GAMEMODE_CHANNEL_NAMES, type Gamemode } from "../utils/gamemodes.js";
import { logAction } from "../utils/logger.js";

const COOLDOWN_DAYS = 5;

export async function handleWaitlistSelect(interaction: StringSelectMenuInteraction) {
  const gamemode = interaction.values[0] as Gamemode;

  if (!interaction.guild) {
    await interaction.reply({ content: "❌ This must be used in a server.", ephemeral: true });
    return;
  }

  // Check if user has a profile
  const user = await db.query.usersTable.findFirst({
    where: eq(usersTable.discordId, interaction.user.id),
  });

  if (!user) {
    await interaction.reply({
      content: "❌ You need to register first! Click **Register / Update Profile** above.",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  // Check cooldown
  const lastEntry = await db.query.waitlistRolesTable.findFirst({
    where: and(
      eq(waitlistRolesTable.userId, interaction.user.id),
      eq(waitlistRolesTable.gamemode, gamemode),
    ),
  });

  if (lastEntry) {
    const diff = Date.now() - new Date(lastEntry.changedAt).getTime();
    const cooldownMs = COOLDOWN_DAYS * 24 * 60 * 60 * 1000;
    const remaining = cooldownMs - diff;

    if (remaining > 0) {
      const days = Math.floor(remaining / (1000 * 60 * 60 * 24));
      const hours = Math.floor((remaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      await interaction.editReply({
        content:
          `⏳ You're on cooldown for the **${gamemode}** waitlist role.\n` +
          `Time remaining: **${days}d ${hours}h**`,
      });
      return;
    }

    // Update existing entry
    await db
      .update(waitlistRolesTable)
      .set({ changedAt: new Date() })
      .where(
        and(
          eq(waitlistRolesTable.userId, interaction.user.id),
          eq(waitlistRolesTable.gamemode, gamemode),
        ),
      );
  } else {
    await db.insert(waitlistRolesTable).values({
      userId: interaction.user.id,
      gamemode,
    });
  }

  // Remove all other waitlist roles
  const member = await interaction.guild.members.fetch(interaction.user.id);
  for (const [gm, roleName] of Object.entries(GAMEMODE_WAITLIST_ROLES)) {
    if (gm !== gamemode) {
      const oldRole = interaction.guild.roles.cache.find((r) => r.name === roleName);
      if (oldRole && member.roles.cache.has(oldRole.id)) {
        await member.roles.remove(oldRole).catch(() => null);
      }
    }
  }

  // Assign new waitlist role
  const roleName = GAMEMODE_WAITLIST_ROLES[gamemode];
  let role = interaction.guild.roles.cache.find((r) => r.name === roleName);
  if (!role) {
    role = await interaction.guild.roles.create({ name: roleName, color: 0x5865f2 });
  }
  await member.roles.add(role).catch(() => null);

  const channelName = GAMEMODE_CHANNEL_NAMES[gamemode];
  const channel = interaction.guild.channels.cache.find((c) => c.name === channelName);

  const embed = new EmbedBuilder()
    .setColor(COLORS.SUCCESS)
    .setTitle("🎉 Waitlist Role Assigned!")
    .setDescription(
      `You received the **Waitlist [${gamemode}]** role!\n\n` +
      `📅 Cooldown ends in **${COOLDOWN_DAYS} day(s)**.\n` +
      `🏷️ Role: <@&${role.id}>\n` +
      `📢 Channel: ${channel ? `<#${channel.id}>` : `#${channelName}`}`,
    )
    .setFooter({ text: "TestYourTier" });

  await logAction(
    interaction.guild,
    "Waitlist Role Assigned",
    interaction.user.id,
    `${gamemode} — IGN: ${user.ign}`,
  );

  await interaction.editReply({ embeds: [embed] });
}
