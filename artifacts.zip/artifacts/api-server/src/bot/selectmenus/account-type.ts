import {
  type StringSelectMenuInteraction,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
} from "discord.js";

export async function handleAccountTypeSelect(interaction: StringSelectMenuInteraction) {
  const accountType = interaction.values[0]; // "premium" or "cracked"

  const modal = new ModalBuilder()
    .setCustomId(`tyt_profile_modal_${accountType}`)
    .setTitle("Profile Registration - Step 2/2");

  const ignInput = new TextInputBuilder()
    .setCustomId("ign")
    .setLabel("In-Game Username (IGN)")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("Your Minecraft username")
    .setRequired(true)
    .setMaxLength(32);

  const skinUrlInput = new TextInputBuilder()
    .setCustomId("skin_url")
    .setLabel("Skin URL (Cracked Only)")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("Paste your skin image URL here (Cracked Only)")
    .setRequired(accountType === "cracked")
    .setMaxLength(500);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(ignInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(skinUrlInput),
  );

  await interaction.showModal(modal);
}
