import { type StringSelectMenuInteraction } from "discord.js";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { buildLeaderboardEmbed, buildLeaderboardButtons, type LeaderboardType } from "../embeds/leaderboard.js";

function getGamemode(safe: string): string {
  const map: Record<string, string> = {
    "Axe___Shield": "Axe & Shield",
    "Axe_&_Shield": "Axe & Shield",
    "Neth_Pot": "Neth Pot",
    "Dia_Pot": "Dia Pot",
    "SMP_Kit": "SMP Kit",
    "Mace": "Mace",
    "Sword": "Sword",
    "UHC": "UHC",
    "CPvP": "CPvP",
    "Overall": "Overall",
  };
  return map[safe] ?? safe.replace(/_/g, " ");
}

export async function handleLeaderboardGamemodeSelect(
  interaction: StringSelectMenuInteraction,
  type: LeaderboardType,
  page: number,
) {
  await interaction.deferUpdate();

  const gamemode = interaction.values[0] ?? "Overall";

  const orderCol =
    type === "points"    ? usersTable.points :
    type === "wins"      ? usersTable.wins :
    type === "winstreak" ? usersTable.winStreak :
                           usersTable.totalTests;

  let users;
  if (gamemode !== "Overall") {
    users = await db.select().from(usersTable).where(eq(usersTable.currentGamemode, gamemode)).orderBy(desc(orderCol));
  } else {
    users = await db.select().from(usersTable).orderBy(desc(orderCol));
  }

  const embed = buildLeaderboardEmbed(users, type, 0, gamemode);
  const components = buildLeaderboardButtons(type, 0, gamemode, users.length);

  await interaction.editReply({ embeds: [embed], components });
}
