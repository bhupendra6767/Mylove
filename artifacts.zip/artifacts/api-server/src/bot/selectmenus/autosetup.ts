import {
  ChannelSelectMenuInteraction,
  ButtonInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ChannelSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  TextChannel,
} from "discord.js";
import { buildRegistrationEmbed, buildRegisterButton, buildWaitlistSelect } from "../embeds/registration.js";
import { buildSupportPortalEmbed, buildSupportButtons } from "../embeds/ticket.js";
import { COLORS } from "../embeds/colors.js";

// ─── Step builders ────────────────────────────────────────────────────────────

type Step = "reg" | "support" | "done";

function buildStep(step: Step) {
  if (step === "done") return buildDone();

  const info = {
    reg: {
      num: "1", total: "2",
      title: "Registration Panel",
      emoji: "📋",
      desc:
        "Pick the channel where the **player registration panel** should be posted.\n" +
        "Players will use it to register their Minecraft account and join the gamemode waitlist.",
      selectId: "tyt_autosetup_reg",
      skipId: "tyt_autosetup_skip_reg",
      placeholder: "Select registration channel…",
    },
    support: {
      num: "2", total: "2",
      title: "Support / Ticket Portal",
      emoji: "🎫",
      desc:
        "Pick the channel where the **support ticket portal** should be posted.\n" +
        "Players will open tickets (reports, appeals, disputes, etc.) from here.",
      selectId: "tyt_autosetup_support",
      skipId: "tyt_autosetup_skip_support",
      placeholder: "Select support/ticket channel…",
    },
  }[step];

  const embed = new EmbedBuilder()
    .setColor(COLORS.PRIMARY)
    .setTitle(`🔧 AutoSetup — Step ${info.num}/${info.total}: ${info.emoji} ${info.title}`)
    .setDescription(info.desc)
    .setFooter({ text: "Click Skip to skip this step and use the channel created by autosetup" });

  const selectRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId(info.selectId)
      .setPlaceholder(info.placeholder)
      .setChannelTypes(ChannelType.GuildText),
  );

  const skipRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(info.skipId)
      .setLabel("Skip this step")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("⏭️"),
  );

  return { embeds: [embed], components: [selectRow, skipRow] };
}

function buildDone() {
  const embed = new EmbedBuilder()
    .setColor(COLORS.SUCCESS)
    .setTitle("🎉 AutoSetup Complete!")
    .setDescription("Your server is fully configured and ready to use.")
    .addFields(
      {
        name: "✅ What was set up",
        value:
          "• All tier roles (HT1–HT5, MT1–MT5, LT1–LT5, Unranked)\n" +
          "• Staff roles (TYT Admin, TYT Staff, TYT High Tester, TYT Tester)\n" +
          "• Waitlist roles for each gamemode\n" +
          "• All queue channels, results channels, staff channels",
        inline: false,
      },
      {
        name: "📋 Next Steps",
        value:
          "• When a tester is ready → run `/setup-queue [gamemode]` in the queue channel\n" +
          "• After a test → run `/result submit` to record the result and update the player's role\n" +
          "• Players can run `/profile` to see their stats\n" +
          "• Everyone can use `/leaderboard` to see rankings",
        inline: false,
      },
    )
    .setTimestamp();

  return { embeds: [embed], components: [] };
}

// ─── Handlers ────────────────────────────────────────────────────────────────

export async function handleAutoSetupChannelSelect(
  interaction: ChannelSelectMenuInteraction,
  step: "reg" | "support",
) {
  await interaction.deferUpdate();

  const channelId = interaction.values[0];
  if (!channelId || !interaction.guild) {
    await interaction.editReply({ content: "❌ No channel selected.", embeds: [], components: [] });
    return;
  }

  const channel = interaction.guild.channels.cache.get(channelId) as TextChannel | undefined;
  if (!channel) {
    await interaction.editReply({ content: "❌ Channel not found.", embeds: [], components: [] });
    return;
  }

  try {
    if (step === "reg") {
      const embed = buildRegistrationEmbed();
      const registerBtn = buildRegisterButton();
      const waitlistSelect = buildWaitlistSelect();
      await channel.send({ embeds: [embed], components: [registerBtn, waitlistSelect] });
    } else {
      const embed = buildSupportPortalEmbed();
      const buttons = buildSupportButtons();
      await channel.send({ embeds: [embed], components: buttons });
    }
  } catch {
    // Channel might not be accessible — continue to next step anyway
  }

  const nextStep: Step = step === "reg" ? "support" : "done";
  const next = buildStep(nextStep);
  await interaction.editReply(next);
}

export async function handleAutoSetupSkip(
  interaction: ButtonInteraction,
  step: "reg" | "support",
) {
  await interaction.deferUpdate();
  const nextStep: Step = step === "reg" ? "support" : "done";
  const next = buildStep(nextStep);
  await interaction.editReply(next);
}

export { buildStep };
