import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";

export const queueEntriesTable = pgTable("queue_entries", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  userId: text("user_id").notNull(),
  gamemode: text("gamemode").notNull(),
  position: integer("position").notNull(),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

export type QueueEntry = typeof queueEntriesTable.$inferSelect;
