import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  discordId: text("discord_id").notNull().unique(),
  username: text("username").notNull(),
  ign: text("ign").notNull(),
  accountType: text("account_type").notNull().default("premium"),
  skinUrl: text("skin_url"),
  currentTier: text("current_tier").notNull().default("Unranked"),
  currentGamemode: text("current_gamemode"),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  points: integer("points").notNull().default(0),
  winStreak: integer("win_streak").notNull().default(0),
  totalTests: integer("total_tests").notNull().default(0),
  queueBanned: boolean("queue_banned").notNull().default(false),
  queueBannedReason: text("queue_banned_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
