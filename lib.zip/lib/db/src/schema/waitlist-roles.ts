import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const waitlistRolesTable = pgTable("waitlist_roles", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  gamemode: text("gamemode").notNull(),
  changedAt: timestamp("changed_at").notNull().defaultNow(),
});

export type WaitlistRole = typeof waitlistRolesTable.$inferSelect;
