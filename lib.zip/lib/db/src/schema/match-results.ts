import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const matchResultsTable = pgTable("match_results", {
  id: serial("id").primaryKey(),
  testerId: text("tester_id").notNull(),
  playerId: text("player_id").notNull(),
  gamemode: text("gamemode").notNull(),
  score: text("score").notNull(),
  previousTier: text("previous_tier").notNull(),
  newTier: text("new_tier").notNull(),
  outcome: text("outcome").notNull().default("tested"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type MatchResult = typeof matchResultsTable.$inferSelect;
