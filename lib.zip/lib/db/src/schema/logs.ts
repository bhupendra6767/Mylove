import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const logsTable = pgTable("logs", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  action: text("action").notNull(),
  userId: text("user_id"),
  details: text("details"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Log = typeof logsTable.$inferSelect;
