import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const ticketsTable = pgTable("tickets", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  category: text("category").notNull(),
  channelId: text("channel_id").notNull().unique(),
  claimedBy: text("claimed_by"),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at"),
});

export type Ticket = typeof ticketsTable.$inferSelect;
