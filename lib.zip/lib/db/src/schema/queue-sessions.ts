import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const queueSessionsTable = pgTable("queue_sessions", {
  id: serial("id").primaryKey(),
  gamemode: text("gamemode").notNull(),
  testerId: text("tester_id").notNull(),
  status: text("status").notNull().default("open"),
  channelId: text("channel_id").notNull(),
  messageId: text("message_id"),
  openedAt: timestamp("opened_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at"),
  closeReason: text("close_reason"),
});

export type QueueSession = typeof queueSessionsTable.$inferSelect;
