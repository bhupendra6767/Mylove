# TestYourTier (TYT)

A production-grade Discord bot for Minecraft PvP ranking, matchmaking, queue management, tier testing, player registration, leaderboards, ticket management, and statistics tracking.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server + Discord bot (port 8080)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string (auto-provisioned)
- Required secrets: `DISCORD_TOKEN`, `DISCORD_CLIENT_ID`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 + Discord.js v14
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- Build: esbuild (ESM bundle)

## Where things live

- `lib/db/src/schema/` — all database table definitions (users, queue-sessions, queue-entries, match-results, tickets, waitlist-roles, logs)
- `artifacts/api-server/src/bot/` — all Discord bot code
  - `commands/` — slash commands
  - `buttons/` — button interaction handlers
  - `modals/` — modal submit handlers
  - `selectmenus/` — select menu handlers
  - `embeds/` — embed builders
  - `utils/` — tiers, gamemodes, permissions, logger
  - `events/` — ready, interactionCreate
  - `deploy.ts` — slash command deployment
  - `index.ts` — bot entry, event wiring

## Architecture decisions

- Bot and Express API run in the same process (single workflow) — simpler deployment on Replit
- Slash commands deployed to guilds on bot startup for instant availability; also deployed globally for new guilds
- Queue state stored in PostgreSQL — survives restarts; active session identified by `status = 'open'`
- Waitlist role cooldowns tracked in `waitlist_roles` table by timestamp diff
- All interaction routing in a single `interactionCreate` handler with regex pattern matching on customIds

## Product

- `/autosetup` — creates all categories, channels, roles automatically
- `/setup-registration` — posts profile registration panel with Register button + waitlist dropdown
- `/setup-queue [gamemode]` — opens a live queue for a gamemode (tester only)
- `/setup-support` — posts the ticket support portal
- `/result submit` — submit a tier test result, updates roles and posts to results channel
- `/profile` — view player profile card
- `/leaderboard` — paginated leaderboard with gamemode filter

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Run `/autosetup` first in a new server to create all required roles and channels
- The bot deploys commands to guilds on startup — it can take a minute for all guilds to receive commands
- Queue embed message ID is stored in `queue_sessions.message_id`; if the message is deleted the embed won't update but the queue still works in DB
- Always invite the bot with `applications.commands` scope for slash commands to work

## Invite URL

Generate at: https://discord.com/developers/applications → OAuth2 → URL Generator
Scopes: `bot`, `applications.commands`
Permissions: `Manage Roles`, `Manage Channels`, `Send Messages`, `Read Message History`, `Manage Messages`, `Create Public Threads`, `Create Private Threads`
